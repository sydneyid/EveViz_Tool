#pragma once
#ifndef ARITHMETIC_H
#define ARITHMETIC_H

#include "../EventScripts/EventManager.h"
#include "../IndexScripts/Index.h"

#include <bits/stdc++.h>

// Find the max attribute of an id event (can receive id, timestamp, or index get functions)
int findMaxAttribute(queue<IdEvent>* id_events_queue, unsigned long long queue_size, int (IdEvent::* get_function_pointer)())
{
    // Check if queue is empty
    if((*id_events_queue).empty() || queue_size == 0)
    {
        return 0; // Return 0 for empty queue
    }
    
    // Initialize variables
    IdEvent current_id_event = (*id_events_queue).front();
    int max_timestamp = (current_id_event.*get_function_pointer)();
    int current_timestamp = max_timestamp;
    unsigned long long queue_counter = 0;
    
    // Quick check of first value
    while (queue_counter<queue_size) {
        current_id_event = (*id_events_queue).front();
        current_timestamp = (current_id_event.*get_function_pointer)();

        if (current_timestamp>max_timestamp)
            max_timestamp = current_timestamp;
        
        (*id_events_queue).pop();
        (*id_events_queue).push(current_id_event);
        queue_counter++;
    }
    return max_timestamp;
}

// Find the max attribute fo an index event
int findMaxAttribute(queue<Index>* id_events_queue, int (Index::* get_function_pointer)())
{
    cout<<"DEBUG: findMaxAttribute(Index) called. Queue size: "<<(*id_events_queue).size()<<"\n";
    
    // Check if queue is empty
    if((*id_events_queue).empty())
    {
        cout<<"DEBUG: Queue is empty, returning 0\n";
        return 0; // Return 0 for empty queue
    }
    
    // Initialize variables
    Index current_id_event = (*id_events_queue).front();
    int max_timestamp = (current_id_event.*get_function_pointer)();
    int current_timestamp = max_timestamp;
    unsigned long long queue_size = (*id_events_queue).size();
    unsigned long long queue_counter = 0;
    
    cout<<"DEBUG: Starting loop. Queue size: "<<queue_size<<"\n";
    
    // Quick check of first value
    while (queue_counter<queue_size) {
        current_id_event = (*id_events_queue).front();
        current_timestamp = (current_id_event.*get_function_pointer)();

        if (current_timestamp>max_timestamp)
            max_timestamp = current_timestamp;
        
        (*id_events_queue).pop();
        (*id_events_queue).push(current_id_event);
        queue_counter++;
    }
    
    cout<<"DEBUG: findMaxAttribute(Index) returning "<<max_timestamp<<". Queue size: "<<(*id_events_queue).size()<<"\n";
    return max_timestamp;
}

// Find the minimum bits needed to represent a number
int findMinimumBitsNeeded(int input_int)
{
    int bits_needed=1;
    int range=2;
    
    // Quick check of first value
    while (range-1<input_int) {
        range=range*2;
        bits_needed++;
    }
    return bits_needed;
}

// Bucket array to check the event length distribution histogram
void eventQueueToBucket(queue<IdEvent>* id_events_queue, unsigned long long  queue_size, int* bucket_array, int bucket_array_length)
{
    // Check if queue is empty
    if((*id_events_queue).empty() || queue_size == 0)
    {
        return; // Nothing to do for empty queue
    }
    
    IdEvent current_id_event = (*id_events_queue).front();
    int queue_counter = 0;
    int current_value = 0;
    
    // Quick check of first value
    while (queue_counter<queue_size) {
        current_id_event = (*id_events_queue).front();
        //Because log2 of 0 is undefined, we use an if to add it to 0, as zero and 1 can be identified by 1 bit
        if(current_id_event.getTimestamp()==0)
            bucket_array[0]++;
        else{
            int index = floor(log2(current_id_event.getTimestamp()));
            bucket_array[index]++;
        }
        
        
        (*id_events_queue).pop();
        (*id_events_queue).push(current_id_event);
        queue_counter++;
    }
}

#endif 