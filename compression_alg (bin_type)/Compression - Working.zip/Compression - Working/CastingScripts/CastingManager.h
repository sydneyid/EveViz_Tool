#pragma once
#ifndef CASTINGMANAGER_H
#define CASTINGMANAGER_H
#include "../EventScripts/Event.h"
#include "../CompressionScripts/CompressedFileHeader.h"
#include <queue>
#include <iostream>
#include<cmath>
#include <stdint.h>

/*
*
*
*       Single element casting functions
*
*
*/

// Receive an event and output a single number long long, does include a trigger value for the huffman compression
long long castEventAsASingleNumber(IdEvent event_to_be_spliced, int trigger_value, int index_size, int timestamp_size)
{
    
    // Only needs timestamp size as we are only doing one
    long long casted_event = 0;

        casted_event|=event_to_be_spliced.getIndexId();
        casted_event<<=timestamp_size;

        casted_event|=event_to_be_spliced.getTimestamp();
        casted_event<<=1;
        casted_event|=trigger_value;

    return casted_event;

}

// Receive an event and output a single number long long, this one doesn't have trigger when huffman isn't compressed
long long castEventAsASingleNumberNOTRIGGER(IdEvent event_to_be_spliced, int timestamp_size)
{
    
    // Only needs timestamp size as we are only doing one
    long long casted_event = 0;
        casted_event|=event_to_be_spliced.getIndexId();
        casted_event<<=timestamp_size;

        casted_event|=event_to_be_spliced.getTimestamp();

    return casted_event;

}

// Reveive a dictionary event and output a single number long long
long long castIdEventAsASingleNumberForDictionary(IdEvent event_to_be_spliced, int index_size, int timestamp_size)
{
    
    // Only needs timestamp size as we are only doing one
    long long casted_event = 0;
        //Get the id and move it the size of index so it doesn't dissapear
        casted_event|=event_to_be_spliced.getEventId();
        casted_event<<=index_size;

        // Get the index and move it the timestamp size so it doesn't dissapear
        casted_event|=event_to_be_spliced.getIndexId();
        casted_event<<=timestamp_size;

        //Get the Timestamp, no need to further move anything
        casted_event|=event_to_be_spliced.getTimestamp();

    return casted_event;

}

// Receive an Index entry and output a single number long long
long long castIndexAsASingleNumber(Index index_to_be_spliced, int initial_timestamp_size)
{
    // Only needs timestamp size as we are only doing one
    long long casted_index = 0;
        //Get the id and move it the size of index so it doesn't dissapear
        casted_index|=index_to_be_spliced.getNumberOfElements();
        casted_index<<=initial_timestamp_size;

        // Get the index and move it the timestamp size so it doesn't dissapear
        casted_index|=index_to_be_spliced.getInitialTimestamp();

    return casted_index;
}

// Due to how long longs work, it is necessary to invert them to re-read the values
long long invertLongLong(long long int_to_be_inverted, int number_of_bits)
{
    long long return_int=0;
    for (int i=0;i<number_of_bits;i++)
    {
        return_int<<=1;
        if (int_to_be_inverted&1==1)
        {
            return_int|=1;
        }
        int_to_be_inverted>>=1;            
    }
    return return_int;
}

// Receive a long long and cast an index
Index castLongLongAsIndex(long long int_to_be_spliced, int index_initial_timestamp_size,int index_initial_timestamp_mask)
{
    //Timestamp mask basically tells you which pixels belong to the timestamp, as marked by 111111111111
    Index return_index;
    // Only needs timestamp size as we are only doing one
    int index_number_of_events = int_to_be_spliced>>index_initial_timestamp_size;
    int index_initial_timestamp = int_to_be_spliced&index_initial_timestamp_mask;
    return_index.setNumberOfElements(index_number_of_events);
    return_index.setInitialTimestamp(index_initial_timestamp);
    return return_index;

}

// Receive a long long and cast an id event
IdEvent castLongLongAsIdEventNoId(long long int_to_be_spliced, int timestamp_size,int timestamp_mask)
{
    //Timestamp mask basically tells you which pixels belong to the timestamp, as marked by 111111111111
    IdEvent return_event;
    // Only needs timestamp size as we are only doing one
    int index_id = int_to_be_spliced>>timestamp_size;
    int timestamp = int_to_be_spliced&timestamp_mask;
    return_event.setIndexId(index_id);
    return_event.setTimestamp(timestamp);
    return return_event;

}

// Receive a long long and cast an index
IdEvent castLongLongAsIdEvent(long long int_to_be_spliced, int index_size, int index_mask, int timestamp_size,int timestamp_mask)
{
    //Timestamp mask basically tells you which pixels belong to the timestamp, as marked by 111111111111
    IdEvent return_event;
    // Move the bits to the right, so only the id remains
    int event_id = int_to_be_spliced>>index_size+timestamp_size;

    int index_id = (int_to_be_spliced>>timestamp_size)&index_mask;

    int timestamp = int_to_be_spliced&timestamp_mask;

    return_event.setEventId(event_id);
    return_event.setIndexId(index_id);
    return_event.setTimestamp(timestamp);
    return return_event;

}

/*
*
*
*       Char List Functions
*
*
*/


// Receives a long long and adds it to a char queue, has a current char that was previously being constructed, size of the event (or entity in long long), a buffer counter to indicate the current position in the event, and a char buffer counter for the position of the char pointer
void castLongLongAsCharList(long long single_int_event, std::queue<char>* char_list_pointer,char* current_char_pointer,int event_total_size, int* event_buffer_counter_pointer, int* char_buffer_counter_pointer, long long* total_char_counter_pointer)
{

    
    //This while will check the current buffer position in the event, and make sure code is still within the event
    while((*event_buffer_counter_pointer)<event_total_size)
    {
        
        //Shift all the bits in current_char to the left by one, automatically adds a zero
        (*current_char_pointer)<<=1;
        (*char_buffer_counter_pointer)++;
        //If the rightmost bit is 1, add it to the char pointer
        if(single_int_event&1==1)
        {
            (*current_char_pointer)|=1;
        }

        //Discard the rightmost bit, and shift everything to the right
        single_int_event>>=1;
        //Check if the char buffer is larger than 7, if so push the current char, reset the current char, and reset the char buffer pointer
        if ((*char_buffer_counter_pointer)>=8)
        {
            (*char_list_pointer).push((*current_char_pointer));
            (*total_char_counter_pointer)++;
            (*current_char_pointer)=0;
            (*char_buffer_counter_pointer)=0;
        }
        (*event_buffer_counter_pointer)++;
    }
    //After finishing with the current event, return the event buffer to zero
    (*event_buffer_counter_pointer)=0;

    
}

// Cast an id events into dictionary header char list to be ready to be added to the file
void castIdEventListAsDictionaryHeaderCharList(std::queue<IdEvent>* dictionary_event_list_pointer, std::queue<char>* char_list_pointer,CompressedFileHeader* compressed_file_header_pointer)
{
    long long  total_char_counter=0;
    long long * total_char_counter_pointer = &total_char_counter;
    int event_counter = 0;
    //Events and chars may be of uneven lenths, as such these buffers will help keep track of which specific bit are we reading/writing
    int char_buffer_counter = 0;
    int* char_buffer_counter_pointer=&char_buffer_counter;
    int event_buffer_counter = 0;
    int* event_buffer_counter_pointer=&event_buffer_counter;

    int event_id_size = (*compressed_file_header_pointer).getDictionaryEncodingIdBitSize();
    int event_index_size = (*compressed_file_header_pointer).getEventIndexSize();
    int event_timestamp_size = (*compressed_file_header_pointer).getEventTimestampSize();
    int event_total_size = event_id_size + event_index_size + event_timestamp_size;

    (*compressed_file_header_pointer).log_entries.push("Event id size(number of event): "+to_string(event_id_size)+" event timestamp size: "+to_string(event_timestamp_size)+"\n");
    (*compressed_file_header_pointer).log_entries.push("Event total size: "+to_string(event_total_size)+"\n");

    if(event_total_size>64)
    {
        (*compressed_file_header_pointer).log_entries.push("ERROR, The event is to big to write as a dictionary encoded, as such, dictionary encoding will be cancelled. To correct this, add a method to split dictionary encoded events\n");
    }

    long long dictionary_event_id = 0;
    long long single_int_event=0;
    char current_char = 0;
    char* current_char_pointer = &current_char;

    IdEvent current_event = (*dictionary_event_list_pointer).front();


    // While there are still dictionary events, cast them into long longs
    while(!(*dictionary_event_list_pointer).empty())
    {
        // FINAL WORK HERE, CAST EVENT AS TWO NUMBERS
        //single_int_event = castIdEventAsASingleNumberForDictionary(current_event,event_index_size,event_timestamp_size);
        dictionary_event_id = current_event.getEventId();
        castLongLongAsCharList(dictionary_event_id,char_list_pointer,current_char_pointer,event_id_size,event_buffer_counter_pointer, char_buffer_counter_pointer, total_char_counter_pointer);

        single_int_event = castEventAsASingleNumberNOTRIGGER(current_event,event_timestamp_size);
        castLongLongAsCharList(single_int_event,char_list_pointer,current_char_pointer,event_total_size,event_buffer_counter_pointer, char_buffer_counter_pointer, total_char_counter_pointer);

        (*dictionary_event_list_pointer).pop();
        
        // Check if queue still has elements before accessing front
        if(!(*dictionary_event_list_pointer).empty())
        {
            current_event = (*dictionary_event_list_pointer).front();
        }
        event_counter++;
    }

    // IT IS IMPERATIVE, THAT AFTER A LONG LONG CAST WE  DO A CHECK FOR THE FINAL BUFFER
    if((*char_buffer_counter_pointer)!=0)
    {
        while((*char_buffer_counter_pointer)<8)
        {
            (*current_char_pointer)<<=1;
            (*char_buffer_counter_pointer)++;
        }
        (*char_list_pointer).push((*current_char_pointer));
        (*total_char_counter_pointer)++;  
    }
    
    (*compressed_file_header_pointer).setNumberOfDictionaryEventChars((*total_char_counter_pointer));
    (*compressed_file_header_pointer).setNumberOfDictionaryEvents(event_counter);

}


// Separate id events into bits and add them into a char list
void bitSpliceIdEventListToCharListNoId(std::queue<IdEvent>* event_list_to_be_split_pointer, std::queue<char>* char_list_pointer,CompressedFileHeader* compressed_file_header_pointer)
{
    
    long long  total_char_counter=0;
    long long * total_char_counter_pointer = &total_char_counter;

    long long total_number_of_huffman_events = 0;
    long long* total_number_of_huffman_events_pointer = &total_number_of_huffman_events;
    long long  total_huffman_char_counter=0;
    long long * total_huffman_char_counter_pointer = &total_huffman_char_counter;
    

    int event_counter = 0;
    //Events and chars may be of uneven lenths, as such these buffers will help keep track of which specific bit are we reading/writing
    int char_buffer_counter = 0;
    int* char_buffer_counter_pointer=&char_buffer_counter;
    int event_buffer_counter = 0;
    int* event_buffer_counter_pointer=&event_buffer_counter;

    // Event without any additional compression techniques, has the largest size
    int event_index_size = (*compressed_file_header_pointer).getEventIndexSize();
    int event_timestamp_size = (*compressed_file_header_pointer).getEventTimestampSize();
    int event_total_size = event_index_size+event_timestamp_size;


    // Event with the dictionary encoding timestamp length. Even though it says long event it should not be larger than the event total size
    int long_event_timestamp_size = (*compressed_file_header_pointer).getDictionaryEncodingTimestampBitSize();
    int long_event_total_size = event_index_size+long_event_timestamp_size+(*compressed_file_header_pointer).getHuffmanTriggerSize();;
    
    int short_event_timestamp_size = (*compressed_file_header_pointer).getHuffmanEncodingTimestampBitSize();
    int short_event_total_size =  event_index_size+short_event_timestamp_size+(*compressed_file_header_pointer).getHuffmanTriggerSize();


    long long single_int_event=0;
    char current_char = 0;
    char* current_char_pointer = &current_char;

    std::queue<IdEvent> dictionary_event_list;
    std::queue<IdEvent>* dictionary_event_list_pointer = &dictionary_event_list;

    std::queue<char> dictionary_char_list;
    std::queue<char>* dictionary_char_list_pointer = &dictionary_char_list;

    //Initialiize the current event
    IdEvent current_event = (*event_list_to_be_split_pointer).front();


    while(!(*event_list_to_be_split_pointer).empty())
    {
        switch (current_event.compression_instruction)
        {
            case IdEvent::CompressionInstruction::NONE:
                // This event is the largest, without any compression
                single_int_event = castEventAsASingleNumberNOTRIGGER(current_event,event_timestamp_size);
                castLongLongAsCharList(single_int_event,char_list_pointer,current_char_pointer,event_total_size,event_buffer_counter_pointer, char_buffer_counter_pointer, total_char_counter_pointer);
            break;

            case IdEvent::CompressionInstruction::HUFFMAN_LONG_EVENT:
                // This event will have a shorter timestamp, but an added trigger of 1
                single_int_event = castEventAsASingleNumber(current_event,1,event_index_size,long_event_timestamp_size);
                castLongLongAsCharList(single_int_event,char_list_pointer,current_char_pointer,long_event_total_size,event_buffer_counter_pointer, char_buffer_counter_pointer, total_huffman_char_counter_pointer);
                (*total_number_of_huffman_events_pointer)++;
            break;

            case IdEvent::CompressionInstruction::HUFFMAN_SHORT_EVENT:
                // Use the short value for the event
                single_int_event = castEventAsASingleNumber(current_event,0,event_index_size,short_event_timestamp_size);
                castLongLongAsCharList(single_int_event,char_list_pointer,current_char_pointer,short_event_total_size,event_buffer_counter_pointer, char_buffer_counter_pointer, total_huffman_char_counter_pointer);
                (*total_number_of_huffman_events_pointer)++;
            
            break;

            case IdEvent::CompressionInstruction::DICTIONARY_ADD_TO_INDEX:
                // Event will be dictionary compressed
                current_event.setEventId(event_counter);
                (*dictionary_event_list_pointer).push(current_event);

                current_event.setTimestamp(0);
            break;
        }


        //Before ending the loop, obtain the next current event
        (*event_list_to_be_split_pointer).pop();
        
        // Check if queue still has elements before accessing front
        if(!(*event_list_to_be_split_pointer).empty())
        {
            current_event = (*event_list_to_be_split_pointer).front();
        }
        event_counter++;
    }
    // Add the leftover char?
    if((*char_buffer_counter_pointer)!=0)
    {
        while((*char_buffer_counter_pointer)<8)
        {
            (*current_char_pointer)<<=1;
            (*char_buffer_counter_pointer)++;
        }
        (*char_list_pointer).push((*current_char_pointer));

        // If there is an additional char, and the file is huffman encoded add it here
        if ((*compressed_file_header_pointer).getIsHuffmanEncoded())
            (*total_huffman_char_counter_pointer)++;  
        // If the file is not huffman encoded, then add it here
        else
            (*total_char_counter_pointer)++;

    }
        
    (*compressed_file_header_pointer).setNumberOfHuffmanEvents((*total_number_of_huffman_events_pointer));
    (*compressed_file_header_pointer).setNumberOfHuffmanEventChars((*total_huffman_char_counter_pointer));

    //If the file is dictionary encoded then proceed
    if((*compressed_file_header_pointer).getIsDictionaryEncoded())
        castIdEventListAsDictionaryHeaderCharList(dictionary_event_list_pointer,dictionary_char_list_pointer,compressed_file_header_pointer);
    //Else just set the values to 0
    else
    {
        (*compressed_file_header_pointer).setNumberOfDictionaryEventChars(0);
        (*compressed_file_header_pointer).setNumberOfDictionaryEvents(0);
    }
    // Add the number of event chars to the compressed file header pointer
    (*compressed_file_header_pointer).setNumberOfEventChars((*total_char_counter_pointer)+(*total_huffman_char_counter_pointer)+(*compressed_file_header_pointer).getNumberOfDictionaryEventChars());

    // Transfer all the dicitonary char list to the 
    while(!(*dictionary_char_list_pointer).empty())
    {
        (*char_list_pointer).push((*dictionary_char_list_pointer).front());
        (*dictionary_char_list_pointer).pop();
    }
    (*compressed_file_header_pointer).log_entries.push("Dictionary event chars added at the end of the char list pointer\n");
    
}


// Bit splice an index list to a char list, same principle as the events
void bitSpliceIndexListToCharList(std::queue<Index>* index_list_to_be_split_pointer, Index::IndexType last_indextype_sort, std::queue<char>* char_list_pointer,CompressedFileHeader* compressed_file_header_pointer)
{
    
    long long  total_index_char_counter=0;
    long long * total_index_char_counter_pointer = &total_index_char_counter;
    

    int index_counter = 0;
    //Events and chars may be of uneven lenths, as such these buffers will help keep track of which specific bit are we reading/writing
    int char_buffer_counter = 0;
    int* char_buffer_counter_pointer=&char_buffer_counter;
    int index_buffer_counter = 0;
    int* index_buffer_counter_pointer=&index_buffer_counter;

    // Event without any additional compression techniques, has the largest size
    int index_entry_size = (*compressed_file_header_pointer).getIndexNumberOfEventsSize();
    int index_initial_timestamp_size = (*compressed_file_header_pointer).getIndexInitialTimestampSize();
    int index_total_size = index_entry_size+index_initial_timestamp_size;    

    long long single_int_index = 0;
    char current_char = 0;
    char* current_char_pointer = &current_char;

    std::queue<IdEvent> dictionary_event_list;
    std::queue<IdEvent>* dictionary_event_list_pointer = &dictionary_event_list;


    //Initialiize the current event
    Index current_index = (*index_list_to_be_split_pointer).front();

    int debug_counter_0 = 0;

    while(!(*index_list_to_be_split_pointer).empty())
    {

        if (current_index.index_type == last_indextype_sort)
        {
            single_int_index = castIndexAsASingleNumber(current_index,index_initial_timestamp_size);

            castLongLongAsCharList(single_int_index, char_list_pointer, current_char_pointer, index_total_size, index_buffer_counter_pointer, char_buffer_counter_pointer, total_index_char_counter_pointer);
            index_counter++;
        }
        //Before ending the loop, obtain the next current event
        (*index_list_to_be_split_pointer).pop();
        
        // Check if queue still has elements before accessing front
        if(!(*index_list_to_be_split_pointer).empty())
        {
            current_index = (*index_list_to_be_split_pointer).front();
        }

    }
    // Add the leftover char?
    if((*char_buffer_counter_pointer)!=0)
    {
        while((*char_buffer_counter_pointer)<8)
        {
            (*current_char_pointer)<<=1;
            (*char_buffer_counter_pointer)++;
        }
        (*char_list_pointer).push((*current_char_pointer));
        (*total_index_char_counter_pointer)++;  
    }

    (*compressed_file_header_pointer).setNumberOfIndexEntriesChars((*total_index_char_counter_pointer));
    (*compressed_file_header_pointer).log_entries.push("Casted the index header as "+to_string((*total_index_char_counter_pointer))+" chars\n");
    
}

// Separate a char queue
void spliceCharQueue(queue<char>* mixed_char_queue, int number_of_event_chars, queue<char>* output_char_queue)
{
    // Get all the events from the mixed queue
    int counter = 0;

    // The first chars of the mixed queue are normal events (huffman)
    for(int i = 0; i<number_of_event_chars; i++)
    {
        (*output_char_queue).push((*mixed_char_queue).front());
        (*mixed_char_queue).pop();
    }
}


// Cast a char list as long long numbers based on the total size of the event (or other element)
void castCharListAsLongLongList(std::queue<char>* char_list_pointer, std::queue<long long>* long_long_list_pointer, int event_total_size)
{
    cout<<"Casting char list as long long list\n";
    int char_buffer=0;
    int event_buffer=0;
    char listed_char = (*char_list_pointer).front();
    long long current_event = 0;
    //char mask =128;
    char current_char=0;

    while(!(*char_list_pointer).empty())
    {    
        listed_char = (*char_list_pointer).front();
        current_char=0;
        for(int i=0; i<8; i++)
        {
            current_char<<=1;
            if(listed_char&1)
                current_char|=1;
            
            listed_char>>=1;
        }

        //While we still have bits in the char
        while(char_buffer<8)
        {
            if(event_buffer>(event_total_size-1))
            {                
                (*long_long_list_pointer).push(invertLongLong(current_event,event_total_size));
                event_buffer=0;
                current_event=0;
                
            }
            else{
                //Shift the current event one bit to the left
                current_event<<=1;

                //If the Leftmost bit is 1 (in this case 128), add one to the rightmost current event
                
                if(current_char&1==1)
                {
                    current_event|=1;
                }
                    
                current_char>>=1;
                event_buffer++;
                char_buffer++;
            }
        }
        char_buffer=0;
        (*char_list_pointer).pop();        
    }
    if(event_buffer==event_total_size)
    {
        cout<<"Untested situation, not sure if adding an extra long long here is correct or not\n";
        (*long_long_list_pointer).push(invertLongLong(current_event,event_total_size));
    }
}

// FINAL WORK HERE
void castCharListAsDictionaryLongLongList(std::queue<char>* char_list_pointer, std::queue<long long>* long_long_list_pointer, int event_total_size_1, int event_total_size_2)
{
    cout<<"Casting char list as long long list\n";
    int char_buffer=0;
    int event_buffer=0;
    char listed_char = (*char_list_pointer).front();
    long long current_event = 0;
    //char mask =128;
    char current_char=0;

    int event_total_size=event_total_size_1;

    while(!(*char_list_pointer).empty())
    {    
        listed_char = (*char_list_pointer).front();
        current_char=0;
        for(int i=0; i<8; i++)
        {
            current_char<<=1;
            if(listed_char&1)
                current_char|=1;
            
            listed_char>>=1;
        }

        //While we still have bits in the char
        while(char_buffer<8)
        {
            if(event_buffer>(event_total_size-1))
            {                
                (*long_long_list_pointer).push(invertLongLong(current_event,event_total_size));
                event_buffer=0;
                current_event=0;
                // Dictionary events will be set in int two long longs, one for the numebr of events and the other one for the event with no trigger
                if(event_total_size==event_total_size_1)
                    event_total_size=event_total_size_2;
                else
                    event_total_size=event_total_size_1;
                
            }
            else{
                //Shift the current event one bit to the left
                current_event<<=1;

                //If the Leftmost bit is 1 (in this case 128), add one to the rightmost current event
                
                if(current_char&1==1)
                {
                    current_event|=1;
                }
                    
                current_char>>=1;
                event_buffer++;
                char_buffer++;
            }
        }
        char_buffer=0;
        (*char_list_pointer).pop();        
    }
    if(event_buffer==event_total_size)
    {
        cout<<"Untested situation, not sure if adding an extra long long here is correct or not\n";
        (*long_long_list_pointer).push(invertLongLong(current_event,event_total_size));
    }
}



// Casting a char list back into huffman variable long longs
void castCharListAsLongLongListHuffmanVariableSize(std::queue<char>* char_list_pointer, std::queue<long long>* long_long_list_pointer, std::queue<bool>* trigger_pointer, int total_short_huffman_event_size, int total_long_huffman_event_size, int total_number_of_huffman_events)
{
    cout<<"Casting char list as long long with huffman variable size\n";
    int char_buffer=0;
    int event_buffer=0;
    char listed_char = (*char_list_pointer).front();
    long long current_event = 0;
    char mask =128;
    char current_char=0;
    //bool flag_is_long;
    bool flag_is_first_bit = true;
    int current_event_total_size = 0;
    int debug_counter = 0;
    
    while(!(*char_list_pointer).empty())
    {
        listed_char = (*char_list_pointer).front();
        current_char=0;
        for(int i=0; i<8; i++)
        {
            current_char<<=1;
            if(listed_char&1)
                current_char|=1;            
            listed_char>>=1;
        }
        if(debug_counter<10){
            cout<<current_char-'0'<<" ";
        }
        //While we still have bits in the char
        while(char_buffer<8)
        {
            // If this is the first bit, therefore is the trigger, check how long the event total size should be
            if(flag_is_first_bit)
            {
                flag_is_first_bit = false;

                // Is long event
                if(current_char&1==1){
                    current_event_total_size = total_long_huffman_event_size;
                    (*trigger_pointer).push(true);

                }
                    
                // Is short event
                else{
                    current_event_total_size = total_short_huffman_event_size;
                    (*trigger_pointer).push(false);
                }

                current_char>>=1;
                char_buffer++;

            }
            else 
            {


                if(event_buffer>(current_event_total_size-1))
                {
                    if(debug_counter<10){
                    cout<<": "<<invertLongLong(current_event,current_event_total_size)<<"\n";
                    }
                    debug_counter++;
                    (*long_long_list_pointer).push(invertLongLong(current_event,current_event_total_size));
                    event_buffer=0;
                    current_event=0;
                    flag_is_first_bit = true;
                }
                else {
                    //Shift the current event one bit to the left
                    current_event<<=1;

                    //If the Leftmost bit is 1 (in this case 128), add one to the rightmost current event
                    
                    if(current_char&1==1)
                    {
                        current_event|=1;
                    }                        
                    current_char>>=1;
                    event_buffer++;
                    char_buffer++;
                }

                
            }
            
        }
        char_buffer=0;
        (*char_list_pointer).pop();
        
    }

    // Add the last one
    if (event_buffer!=0&&(*long_long_list_pointer).size()<total_number_of_huffman_events)
    {        
        (*long_long_list_pointer).push(invertLongLong(current_event,current_event_total_size));
        event_buffer=0;
        current_event=0;
    }

}

// Casting a char list as an index
void castCharListAsIndex(queue<char>*index_chars_pointer,queue<Index>* index_queue_pointer,CompressedFileHeader* compressed_file_chars_pointer)
{


    cout<<"Casting Char list as Index\n";
    queue<long long> index_long_long_queue;
    queue<long long>* index_long_long_queue_pointer = &index_long_long_queue;

    int index_number_of_events_size = (*compressed_file_chars_pointer).getIndexNumberOfEventsSize();
    int index_initial_timestamp_size = (*compressed_file_chars_pointer).getIndexInitialTimestampSize();

    int total_index_size = index_number_of_events_size + index_initial_timestamp_size;

    cout<<"Total Index Size: Number of events size"<<index_number_of_events_size<<" + initial timestamp size: "<<index_initial_timestamp_size<<"\n";
    
    castCharListAsLongLongList(index_chars_pointer,index_long_long_queue_pointer, total_index_size);


    // Masks will help us separate the bits from the single number into multiple ones
    int index_initial_timestamp_mask = 0;


    for(int i=0;i<index_initial_timestamp_size;i++){
        index_initial_timestamp_mask<<=1;
        index_initial_timestamp_mask|=1;
    }

    cout<<"Index reobtained from the file:";
    int debug_counter_1 = 0;

    while(!(*index_long_long_queue_pointer).empty())
    {
        (*index_queue_pointer).push(castLongLongAsIndex((*index_long_long_queue_pointer).front(),index_initial_timestamp_size,index_initial_timestamp_mask));
        if(debug_counter_1<10)
            cout<<" "<<(*index_long_long_queue_pointer).front()<<" "<<indexToString((*index_queue_pointer).back())<<" |";
        debug_counter_1++;
        (*index_long_long_queue_pointer).pop();
    }
    cout<<"\n";
}

// Casting a char list as dictionary id events
void castCharListAsDictionaryIdEvents(queue<char>*dictionary_chars_pointer,queue<IdEvent>* dictionary_id_events_pointer,CompressedFileHeader* compressed_file_chars_pointer)
{
    cout<<"Casting char list as Dictionary Id Events\n";
    queue<long long> dictionary_long_long_queue;
    queue<long long>* dictionary_long_long_queue_pointer = &dictionary_long_long_queue;

    int id_size = (*compressed_file_chars_pointer).getDictionaryEncodingIdBitSize();
    int index_size = (*compressed_file_chars_pointer).getEventIndexSize();
    int timestamp_size = (*compressed_file_chars_pointer).getEventTimestampSize();

    int total_dictionary_event_size = id_size + index_size + timestamp_size;

    cout<<"Total Dictionary Event Size: id"<<id_size<<" + index"<<index_size<<" + timestamp"<<timestamp_size<<" = "<<total_dictionary_event_size<<"\n";

    cout<<"Dictionary char list size: "<<(*dictionary_chars_pointer).size()<<"\n";
    
    castCharListAsDictionaryLongLongList(dictionary_chars_pointer,dictionary_long_long_queue_pointer, id_size, total_dictionary_event_size);

    cout<<"Dictionary long long list size: "<<(*dictionary_long_long_queue_pointer).size()<<"\n";


    // Masks will help us separate the bits from the single number into multiple ones
    int index_mask = 0;
    int timestamp_mask = 0;

    for(int i=0;i<index_size;i++){
        index_mask<<=1;
        index_mask|=1;
    }

    for(int i=0;i<timestamp_size;i++){
        timestamp_mask<<=1;
        timestamp_mask|=1;
    }

    int event_id=0;
    IdEvent event_to_be_added;

    while(!(*dictionary_long_long_queue_pointer).empty())
    {
        // FINAL WORK HERE
        event_id=((*dictionary_long_long_queue_pointer).front());
        //(*dictionary_id_events_pointer).push(castLongLongAsIdEvent((*dictionary_long_long_queue_pointer).front(),index_size,index_mask,timestamp_size,timestamp_mask));
        (*dictionary_long_long_queue_pointer).pop();

        if(!(*dictionary_long_long_queue_pointer).empty())
        {
            event_to_be_added = castLongLongAsIdEventNoId((*dictionary_long_long_queue_pointer).front(),timestamp_size,timestamp_mask);
            event_to_be_added.setEventId(event_id);
            
            (*dictionary_id_events_pointer).push(event_to_be_added);
            (*dictionary_long_long_queue_pointer).pop();
        }
    }
    cout<<"Dictionary Events total size: "<<(*dictionary_id_events_pointer).size()<<"\n";
}

// Casting a charlist as id events
void castCharListAsIdEvents(queue<char>*event_chars_pointer,queue<IdEvent>* id_events_pointer,CompressedFileHeader* compressed_file_chars_pointer)
{
    cout<<"Events with no addittional encoding strategy\n";
    queue<long long> event_long_long_queue;
    queue<long long>* event_long_long_queue_pointer = &event_long_long_queue;

    //int id_size = (*compressed_file_chars_pointer).getDictionaryEncodingIdBitSize();
    int index_size = (*compressed_file_chars_pointer).getEventIndexSize();
    int timestamp_size = (*compressed_file_chars_pointer).getEventTimestampSize();    

    int total_event_size = index_size + timestamp_size;

    cout<<"Index size:"<<index_size<<"\n";
    cout<<"Total Event size: "<<total_event_size<<"\n";

    int timestamp_mask = 0;

    for(int i=0;i<timestamp_size;i++){
        timestamp_mask<<=1;
        timestamp_mask|=1;
    }


    castCharListAsLongLongList(event_chars_pointer, event_long_long_queue_pointer, total_event_size);


    int debug_event_counter = 0;
    cout<<"HUFFMAN LONG LONG TO ID EVENT ANALYSIS\n";

    while(!(*event_long_long_queue_pointer).empty())
    {
        (*id_events_pointer).push(castLongLongAsIdEventNoId((*event_long_long_queue_pointer).front(),timestamp_size,timestamp_mask));
        if (debug_event_counter<10)
            cout<<(*event_long_long_queue_pointer).front()<<" | "<<idEventToString((*id_events_pointer).back());
        (*event_long_long_queue_pointer).pop();


        debug_event_counter++;        
    }
    cout<<"Total number of no addittional encoding strategy events "<<debug_event_counter<<"\n";
}

// Casting char list as huffman Id events
void castCharListAsHuffmanIdEvents(queue<char>*huffman_chars_pointer,queue<IdEvent>* huffman_id_events_pointer,CompressedFileHeader* compressed_file_chars_pointer)
{
    cout<<"The File is Huffman Encoded\n";
    queue<long long> huffman_long_long_queue;
    queue<long long>* huffman_long_long_queue_pointer = &huffman_long_long_queue;
    queue<bool> trigger_queue;
    queue<bool>* trigger_queue_pointer = &trigger_queue;

    //int id_size = (*compressed_file_chars_pointer).getDictionaryEncodingIdBitSize();
    int index_size = (*compressed_file_chars_pointer).getEventIndexSize();
    int short_timestamp_size = (*compressed_file_chars_pointer).getHuffmanEncodingTimestampBitSize();
    int long_timestamp_size = (*compressed_file_chars_pointer).getDictionaryEncodingTimestampBitSize();
    

    int total_short_huffman_event_size = index_size + short_timestamp_size;
    int total_long_huffman_event_size = index_size + long_timestamp_size;

    cout<<"Index size:"<<index_size<<"\n";
    cout<<"Short Event: "<<total_short_huffman_event_size<<"\n";
    cout<<"Large Event: "<<total_long_huffman_event_size<<"\n";

    int short_timestamp_mask = 0;
    int long_timestamp_mask = 0;

    for(int i=0;i<short_timestamp_size;i++){
        short_timestamp_mask<<=1;
        short_timestamp_mask|=1;
    }

    for(int i=0;i<long_timestamp_size;i++){
        long_timestamp_mask<<=1;
        long_timestamp_mask|=1;
    }

    
    castCharListAsLongLongListHuffmanVariableSize(huffman_chars_pointer, huffman_long_long_queue_pointer, trigger_queue_pointer, total_short_huffman_event_size, total_long_huffman_event_size,(*compressed_file_chars_pointer).getNumberOfHuffmanEvents());
    cout<<"Size of long long huffmans: "<<(*huffman_long_long_queue_pointer).size()<<'\n';


    int debug_event_counter = 0;
    cout<<"Huffman long long analysis\n";

    while(!(*huffman_long_long_queue_pointer).empty())
    {
        if((*trigger_queue_pointer).front())
        {
            (*huffman_id_events_pointer).push(castLongLongAsIdEventNoId((*huffman_long_long_queue_pointer).front(),long_timestamp_size,long_timestamp_mask));
            if (debug_event_counter<10)
                cout<<(*huffman_long_long_queue_pointer).front()<<" | "<<idEventToString((*huffman_id_events_pointer).back());
        }
            
        else{
            (*huffman_id_events_pointer).push(castLongLongAsIdEventNoId((*huffman_long_long_queue_pointer).front(),short_timestamp_size,short_timestamp_mask));
            if (debug_event_counter<10)
                cout<<(*huffman_long_long_queue_pointer).front()<<" | "<<idEventToString((*huffman_id_events_pointer).back());
        }

        (*trigger_queue_pointer).pop();
        (*huffman_long_long_queue_pointer).pop();


        debug_event_counter++;
    }
    cout<<"Total number of huffman events "<<debug_event_counter<<"\n";
}

/*
*
*
*       Debugging functions
*
*
*/

void debugBitList(std::queue<char>* bit_list_pointer, int counter)
{
    cout<<"Debugging Bit list\n";
    for (int i = 0; i < counter; ++i) 
    {
        (*bit_list_pointer).push((*bit_list_pointer).front());
        cout<<(int)(*bit_list_pointer).front();
        (*bit_list_pointer).pop();
        if (i%8==0&&i>1)
            cout<<".";
    }
    cout<<"\n";
}

void debugCharList(std::queue<char>* char_list_pointer, int counter)
{
    cout<<"Debugging Char list\n";
    for (int i = 0; i < counter; ++i) 
    {
        (*char_list_pointer).push((*char_list_pointer).front());
        cout<<(int)(*char_list_pointer).front()<<" ";
        (*char_list_pointer).pop();

    }
    cout<<"\n";
}

void debugUnsignedCharList(std::queue<unsigned char>* char_list_pointer, int counter)
{
    cout<<"Debugging Unsigned Char list\n";
    for (int i = 0; i < counter; ++i) 
    {
        (*char_list_pointer).push((*char_list_pointer).front());
        cout<<(int)(*char_list_pointer).front()<<" ";
        (*char_list_pointer).pop();

    }
    cout<<"\n";
}

#endif