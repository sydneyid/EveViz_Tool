#pragma once
#ifndef CompressedFileHeader_H
#define CompressedFileHeader_H
#include "../EventScripts/EventManager.h"
#include <string>
#include <iostream>
#include <queue>
// Compressed file header is perhaps one of the most important aspects of the code, it is a checklist that will be filled and added to the compressed file
// It will take care of writing the instructions necessary for decoding the file
class CompressedFileHeader
{
    private:
        long long skip_header=0;
        //char value_separator_character = ','; // How each value is separated, for example comma or space ' '
        int x_min = 0;
        int x_max = 0;
        int y_min = 0;
        int y_max = 0;
        int polarity = 1;
        //IdEvent initial_event;
        long long initial_timestamp = 0;
        long long number_of_event_chars;
        long long number_of_events;
        long long event_index_size; // How long is the index of the id event per entry
        long long event_timestamp_size; // How long is the timestamp of each id event
        long long header_char_counter;
        std::string header;
        char value_separator = '#';
        char header_terminator = '\n';
        char event_data_separator = ',';

        // Additional Compression Algorithms
        // Index
        long long is_index_encoded = 0;
        long long index_number_of_event_size = 0;
        long long index_initial_timestamp_size = 0;
        long long number_of_index_entries_chars = 0;
        long long number_of_index_entries = 0;
        //long long full_size_of_index = 0; // Not to be written in the file, simply for arithmentic purposes
        // Dictionary
        long long is_dictionary_encoded=false;
        // Anything above this bit size will be dictionary encoded
        long long dictionary_encoded_id_bit_size = 0;
        long long dictionary_encoding_timestamp_bit_size = 0;
        long long number_of_dictionary_event_chars = 0;
        long long number_of_dictionary_events = 0;
        // Huffman
        long long is_huffman_encoded=false;
        // Anything above this bit size will be long huffman encoded
        long long huffman_encoding_timestamp_bit_size = 0;
        long long huffman_trigger_size = 0;
        long long number_of_huffman_event_chars = 0;
        long long number_of_huffman_events = 0;




    public:
        // Log entries will help us debug or check intermediary output steps
        queue<std::string> log_entries;

        CompressedFileHeader()
                : initial_timestamp{0}
                , number_of_event_chars{0}
                , event_index_size{0}
                , event_timestamp_size{0}
                , header_char_counter{0}
                , header{""}
        {}
        // If the file does not have a header
        long long getSkipHeader()
        {
            return skip_header;
        }
        // Used in all compression algorithms
        long long getInitialTimestamp()
        {
            return initial_timestamp;
        }
        long long  getNumberOfEventChars()
        {
            return number_of_event_chars;
        }
        long long getEventIndexSize()
        {
            return event_index_size;
        }
        long long getEventTimestampSize()
        {
            return event_timestamp_size;
        }
        // Index encoding
        long long getIsIndexEncoded()
        {
            return is_index_encoded;
        }
        long long getIndexNumberOfEventsSize()
        {
            return index_number_of_event_size;
        }
        long long getIndexInitialTimestampSize()
        {
            return index_initial_timestamp_size;
        }
        long long getNumberOfIndexEntriesChars()
        {
            return number_of_index_entries_chars;
        }
        long long getNumberOfIndexEntries()
        {
            return number_of_index_entries;
        }
        // Dictionary encoding
        long long getIsDictionaryEncoded()
        {
            return is_dictionary_encoded;
        }
        long long getDictionaryEncodingIdBitSize()
        {
            return dictionary_encoded_id_bit_size;
        }
        long long getDictionaryEncodingTimestampBitSize()
        {
            return dictionary_encoding_timestamp_bit_size;
        }
        long long  getNumberOfDictionaryEvents()
        {
            return number_of_dictionary_events;
        }
        long long  getNumberOfDictionaryEventChars()
        {
            return number_of_dictionary_event_chars;
        }
        // Huffman encoding
        long long getIsHuffmanEncoded()
        {
            return is_huffman_encoded;
        }
        long long  getNumberOfHuffmanEvents()
        {
            return number_of_huffman_events;
        }
        long long  getNumberOfHuffmanEventChars()
        {
            return number_of_huffman_event_chars;
        }
        long long getHuffmanEncodingTimestampBitSize()
        {
            return huffman_encoding_timestamp_bit_size;
        }
        long long getHuffmanTriggerSize()
        {
            return huffman_trigger_size;
        }
        // Additional parameters
        long long getHeaderCharCount()
        {
            return header_char_counter;
        }
        char getValueSeparator()
        {
            return value_separator;
        }
        char getHeaderTerminator()
        {
            return header_terminator;
        }
        long long getNumberOfEvents()
        {
            return number_of_events;
        }
        std::string getHeader()
        {
            return header;
        }

        int getXMin()
        {
            return x_min;
        }
        int getXMax()
        {
            return x_max;
        }
        int getYMin()
        {
            return y_min;
        }
        int getYMax()
        {
            return y_max;
        }
        int getPolarity()
        {
            return polarity;
        }
        char getEventValueSeparator()
        {
            return event_data_separator;
        }

        // Write all the information as a string
        std::string toString()
        {
            std::string return_string="";
            return_string+= "Values are separated with the value separator <#> header terminates with char <\\n> order of chars is index>huffman>dictionary the order of values is an empty 0 to debug,\
skip header, the initial event timestamp, number of chars, event index size, event timestamp size, \
is index encoded (bits represent xypol), number of index entries chars, number of index entries, index number of event size, index initial timestamp size, \
is dictionary encoded, number of dictionary event chars, number of dictionary events, dictionary encoding id bit size, dictionary encoding timestamp bit size, \
is huffman encoded, huffman encoded timestamp bit size, huffman trigger size, \
debugging error, we are still missing the raw event file information to be added (min max x y z), as well as the order of compression algorithms used";

            //value_separator+idEventToFileFormat(initial_event,value_separator)+
            return_string+=value_separator+
            to_string(skip_header)+value_separator+
            to_string(initial_timestamp)+value_separator+
            
            to_string(number_of_event_chars)+value_separator+

            to_string(event_index_size)+value_separator+
            to_string(event_timestamp_size)+value_separator+

            to_string(is_index_encoded)+value_separator+
            to_string(number_of_index_entries_chars)+value_separator+
            to_string(number_of_index_entries)+value_separator+
            to_string(index_number_of_event_size)+value_separator+
            to_string(index_initial_timestamp_size)+value_separator+
            
            to_string(is_dictionary_encoded)+value_separator+
            to_string(number_of_dictionary_event_chars)+value_separator+
            to_string(number_of_dictionary_events)+value_separator+
            to_string(dictionary_encoded_id_bit_size)+value_separator+
            to_string(dictionary_encoding_timestamp_bit_size)+value_separator+
            
            to_string(is_huffman_encoded)+value_separator+
            to_string(number_of_huffman_event_chars)+value_separator+
            to_string(number_of_huffman_events)+value_separator+
            to_string(huffman_encoding_timestamp_bit_size)+value_separator+
            to_string(huffman_trigger_size)+

            value_separator+header+"\n";

            return return_string;
        }

        // Set Functions
        // General
        void setSkipHeader(long long input_skip_header)
        {
            skip_header=input_skip_header;
        }
        void setInitialTimestamp(long long input_initial_timestamp)
        {
            initial_timestamp = input_initial_timestamp;
        }
        void setNumberOfEventChars(long long input_number_of_events_chars)
        {
            number_of_event_chars = input_number_of_events_chars;
        }
        void setEventIndexSize(long long input_set_index_size)
        {
            event_index_size = input_set_index_size;
        }
        void setEventTimestampSize(long long input_set_timestamp_size)
        {
            event_timestamp_size = input_set_timestamp_size;
        }
        void setHeaderCharCount(long long input_header_char_counter)
        {
            header_char_counter = input_header_char_counter;
        }
        void setHeader(std::string input_header)
        {
            header = input_header;
            x_min = 0;
            y_min = 0;
            polarity = 1;
            int pos = 0;
            pos = input_header.find(':');
            input_header.erase(0, pos + 1);
            pos = input_header.find(',');
            x_max = stoi(input_header.substr(0, pos))-1;
            input_header.erase(0, pos + 1);
            y_max = stoi(input_header)-1;
        
        }
        void setNumberOfEvents(long long input_number_of_events)
        {
            number_of_events = input_number_of_events;
        }
        // Index
        void setIsIndexEncoded(long long input_is_index_encoded)
        {
            is_index_encoded = input_is_index_encoded;
        }
        void setIndexNumberOfEventSize(long long input_index_number_of_event_size)
        {
            index_number_of_event_size = input_index_number_of_event_size;
        }
        void setIndexInitialTimestampSize(long long input_index_initial_timestamp_size)
        {
            index_initial_timestamp_size = input_index_initial_timestamp_size;
        }
        void setNumberOfIndexEntriesChars(long long input_number_of_index_entries_chars)
        {
            number_of_index_entries_chars = input_number_of_index_entries_chars;
        }
        void setNumberOfIndexEntries(long long input_number_of_index_entries)
        {
            number_of_index_entries = input_number_of_index_entries;
        }
        // Dictionary
        void setIsDictionaryEncoded(long long input_is_dictionary_encoded)
        {
            is_dictionary_encoded = input_is_dictionary_encoded;
        }
        void setDictionaryEncodingIdBitSize(long long input_dictionary_encoded_id_bit_size)
        {
            dictionary_encoded_id_bit_size = input_dictionary_encoded_id_bit_size;
        }
        void setDictionaryEncodingTimestampBitSize(long long input_dictionary_encoding_timestamp_bit_size)
        {
            dictionary_encoding_timestamp_bit_size = input_dictionary_encoding_timestamp_bit_size;
        }
        void setNumberOfDictionaryEventChars(long long input_number_of_dictionary_events_chars)
        {
            number_of_dictionary_event_chars = input_number_of_dictionary_events_chars;
        }
        void setNumberOfDictionaryEvents(long long input_number_of_dictionary_events)
        {
            number_of_dictionary_events = input_number_of_dictionary_events;
        }
        // Huffman
        void setHuffmanEncodingTimestampBitSize(long long input_huffman_encoding_timestamp_bit_size)
        {
            huffman_encoding_timestamp_bit_size = input_huffman_encoding_timestamp_bit_size;
        }
        void setNumberOfHuffmanEventChars(long long input_number_of_huffman_event_chars)
        {
            number_of_huffman_event_chars = input_number_of_huffman_event_chars;
        }
        void setNumberOfHuffmanEvents(long long input_number_of_huffman_events)
        {
            number_of_huffman_events = input_number_of_huffman_events;
        }
        void setIsHuffmanEncoded(long long input_is_huffman_encoded)
        {
            is_huffman_encoded = input_is_huffman_encoded;
        }
        void setHuffmanTriggerSize(long long input_huffman_trigger_size)
        {
            huffman_trigger_size = input_huffman_trigger_size;
        }


};

// Receive the information of a compressed file header as long longs and set them to the actual instance of the compressed file header
void longlongVectorToCompressedFileHeader(vector<long long>* vector_pointer,CompressedFileHeader* compressed_file_header_pointer,std::string token)
{
    int counter = 0;

    (*compressed_file_header_pointer).setSkipHeader((*vector_pointer)[counter]);
    counter++;
    (*compressed_file_header_pointer).setInitialTimestamp((*vector_pointer)[counter]);
    counter++;
    (*compressed_file_header_pointer).setNumberOfEventChars((*vector_pointer)[counter]);
    counter++;
    (*compressed_file_header_pointer).setEventIndexSize((*vector_pointer)[counter]);
    counter++;
    (*compressed_file_header_pointer).setEventTimestampSize((*vector_pointer)[counter]);
    counter++;

    // Index
    (*compressed_file_header_pointer).setIsIndexEncoded((*vector_pointer)[counter]);
    counter++;
    (*compressed_file_header_pointer).setNumberOfIndexEntriesChars((*vector_pointer)[counter]);
    counter++;
    (*compressed_file_header_pointer).setNumberOfIndexEntries((*vector_pointer)[counter]);
    counter++;
    (*compressed_file_header_pointer).setIndexNumberOfEventSize((*vector_pointer)[counter]);
    counter++;
    (*compressed_file_header_pointer).setIndexInitialTimestampSize((*vector_pointer)[counter]);
    counter++;


    (*compressed_file_header_pointer).setIsDictionaryEncoded((*vector_pointer)[counter]);
    counter++;
    (*compressed_file_header_pointer).setNumberOfDictionaryEventChars((*vector_pointer)[counter]);
    counter++;
    (*compressed_file_header_pointer).setNumberOfDictionaryEvents((*vector_pointer)[counter]);
    counter++;
    (*compressed_file_header_pointer).setDictionaryEncodingIdBitSize((*vector_pointer)[counter]);
    counter++;
    (*compressed_file_header_pointer).setDictionaryEncodingTimestampBitSize((*vector_pointer)[counter]);
    counter++;
    (*compressed_file_header_pointer).setIsHuffmanEncoded((*vector_pointer)[counter]);
    counter++;
    (*compressed_file_header_pointer).setNumberOfHuffmanEventChars((*vector_pointer)[counter]);
    counter++;
    (*compressed_file_header_pointer).setNumberOfHuffmanEvents((*vector_pointer)[counter]);
    counter++;
    (*compressed_file_header_pointer).setHuffmanEncodingTimestampBitSize((*vector_pointer)[counter]);
    counter++;
    (*compressed_file_header_pointer).setHuffmanTriggerSize((*vector_pointer)[counter]);
    counter++;
    (*compressed_file_header_pointer).setHeader(token);
    counter++;
    
}

//Rebuild the CompressedFileHeader from a string
CompressedFileHeader stringToCompressedFileHeader(string input_string)
{
    CompressedFileHeader compressed_file_header;
    CompressedFileHeader* compressed_file_header_pointer = &compressed_file_header;
    
    std::vector<long long> tokens;
    std::vector<long long>* tokens_pointer = &tokens;
    size_t pos = 0;
    std::string token;
    char value_separator = compressed_file_header.getValueSeparator();
    cout<<"\n Inside String to compressed file header, checking error\n";

    // Eliminate the first and second % as that is where the values truly begin
    // Example %
    pos = input_string.find(value_separator);
    cout<<pos;
    input_string.erase(0, pos + 1);
    // Initial value
    pos = input_string.find(value_separator);
    input_string.erase(0, pos + 1);

    while ((pos = input_string.find(value_separator)) != std::string::npos) {
        token = input_string.substr(0, pos);
        tokens.push_back(stoll(token));
        input_string.erase(0, pos + 1);
    }
    // Save the last token string, add it to the long long vector entry
    token = input_string.substr(0, pos);

    longlongVectorToCompressedFileHeader(tokens_pointer,compressed_file_header_pointer,token);
    return compressed_file_header;
}



#endif