#pragma once
#ifndef CompressionManager_H
#define CompressionManager_H
#include "../EventScripts/EventManager.h"
#include "../IndexScripts/IndexManager.h"
#include "../InputOutputScripts/InputOutputManager.h"
#include "../ArithmeticScripts/Arithmetic.h"
#include "../CompressionScripts/CompressedFileHeader.h"

/*Events Functions*/

// Compress an event queue with delta compression, typically only the timestamp will be delta comrpessed
void deltaCompressEventQueue(queue<Index>* index_queue_pointer,queue<Event>* uncompressed_events_queue_pointer, queue<Event>* compressed_events_queue_pointer, int (Event::* get_function_pointer)(), void (Event::* set_function_pointer)(int),Index::IndexType input_sorting_type,CompressedFileHeader* compressed_file_header_pointer)
{
    cout<<"DEBUG: deltaCompressEventQueue called. Index queue size: "<<(*index_queue_pointer).size()<<"\n";
    
    // Check if queues are empty
    if((*index_queue_pointer).empty())
    {
        cout<<"ERROR: Index queue is empty in deltaCompressEventQueue\n";
        return;
    }
    
    // This code will execute differently if index only has 1 entry, as 
    Index front_index = (*index_queue_pointer).front();
    
    cout<<"DEBUG: Got front_index. About to get front event\n";
    cout<<"DEBUG: Uncompressed events queue size: "<<(*uncompressed_events_queue_pointer).size()<<"\n";
    
    if((*uncompressed_events_queue_pointer).empty())
    {
        cout<<"ERROR: uncompressed_events_queue is empty!\n";
        return;
    }
    
    Event current_event = (*uncompressed_events_queue_pointer).front();
    cout<<"DEBUG: Got current_event\n";
    int event_counter=0;

    int previous_event_data_value = (current_event.*get_function_pointer)();
    int current_event_data_value = (current_event.*get_function_pointer)();

    cout<<"DEBUG: Got event data values\n";
    
    if(front_index.index_type!=Index::START){
        (*compressed_file_header_pointer).log_entries.push("ERROR the index first element was not start, this means the index queue is not correctly used. Please start the queue with a start type, and push it at the end for iteration purposes\n");
    }

    cout<<"DEBUG: About to pop/push index queue\n";
    
    // Loop the start event to the back, will help us know when we have fully gone over the indexes
    (*index_queue_pointer).pop();
    (*index_queue_pointer).push(front_index);

    cout<<"DEBUG: Popped and pushed. Checking front()...\n";
    
    // If for the first index is still start, that means that there is no index to be compressed, therefore a quick algorithm is done
    if((*index_queue_pointer).front().index_type==Index::START)
    {
        cout<<"DEBUG: Front is START, entering no-index branch\n";
        if(!(*uncompressed_events_queue_pointer).empty())
            {
                event_counter=0;
                cout<<"DEBUG: Starting while loop to process events\n";
                // While there are still values in the partitioned queue sort them
                while(!(*uncompressed_events_queue_pointer).empty()&&event_counter<front_index.getNumberOfElements())
                {
                    // Get the next event
                    current_event = (*uncompressed_events_queue_pointer).front();
                    (*uncompressed_events_queue_pointer).pop();

                    // Save current timestamp in a variable
                    current_event_data_value = (current_event.*get_function_pointer)();;

                    // Compress the current event timestamp
                    int value_to_be_added = current_event_data_value-previous_event_data_value;

                    // If this is the first element in the index, add a zero, as the value should be saved in the index
                    if (event_counter==0)
                        value_to_be_added=0;
                    (current_event.*set_function_pointer)(value_to_be_added);

                    // Add the compressed event to the compressed queue
                    (*compressed_events_queue_pointer).push(current_event);

                    //Set previous timestamp to the uncompressed current timestamp
                    previous_event_data_value = current_event_data_value;
                    
                    event_counter++;
                }
            }
    }

    cout<<"DEBUG: Exited first processing block. About to check second while loop condition.\n";
    cout<<"DEBUG: Index queue size before second while: "<<(*index_queue_pointer).size()<<"\n";
    if(!(*index_queue_pointer).empty()) {
        cout<<"DEBUG: Index queue front type: "<<(*index_queue_pointer).front().index_type<<" (START="<<Index::START<<")\n";
    }
    
    // Because we already have an index set up, we will iterate until we find the start again thanks to the Index::START tag
    // In this case every algorithm except no index will be executed here
    // Same algorithm as above, but uses the index as well
    while (!(*index_queue_pointer).empty() && (*index_queue_pointer).front().index_type!=Index::START) 
    {  
        cout<<"DEBUG: Entered second while loop\n";
        Index current_index=(*index_queue_pointer).front();

        // If the index is of a different type than the input, we skip it. You enter here when you already sorted by X and Y, but still need to do polarity by Y. You would then skip all the X 
        if(current_index.index_type==input_sorting_type)
        {
            if(!(*uncompressed_events_queue_pointer).empty())
            {
                // Change the initial timestamp of the current event
                current_index.setInitialTimestamp((*uncompressed_events_queue_pointer).front().getTimestamp());
                event_counter=0;

                // While there are still values in the partitioned queue sort them
                while(!(*uncompressed_events_queue_pointer).empty()&&event_counter<current_index.getNumberOfElements())
                {
                    // Get the next event
                    current_event = (*uncompressed_events_queue_pointer).front();
                    (*uncompressed_events_queue_pointer).pop();

                    // Save current timestamp in a variable
                    current_event_data_value = (current_event.*get_function_pointer)();;

                    // Compress the current event timestamp
                    int value_to_be_added = current_event_data_value-previous_event_data_value;
                    
                    // If this is the first element in the index, add a zero, as the value should be saved in the index
                    if (event_counter==0)
                        value_to_be_added=0;
                    (current_event.*set_function_pointer)(value_to_be_added);

                    // Add the compressed event to the compressed queue
                    (*compressed_events_queue_pointer).push(current_event);

                    //Set previous timestamp to the uncompressed current timestamp
                    previous_event_data_value = current_event_data_value;
                    
                    event_counter++;
                }
            }
        }
        // Current index is added afterwards as we need to set the initial timestamp
        (*index_queue_pointer).push(current_index);
        (*index_queue_pointer).pop();
    }
    
    cout<<"DEBUG: deltaCompressEventQueue exiting. Index queue size: "<<(*index_queue_pointer).size()<<"\n";
}

/*ID Events Functions*/

// Compress an event queue into an id event queue
void compressEventQueuetoIdEventQueue(queue<Event>* uncompressed_events, queue<IdEvent>* compressed_events, int x_multiplier, int y_multiplier, int polarity_multiplier)
{
    int counter=0;
    // Find initial event
    Event current_uncompressed_event = (*uncompressed_events).front();

    while(!(*uncompressed_events).empty())
    {
        // Get the current uncompressed event
        current_uncompressed_event = (*uncompressed_events).front();

        // Rransform the uncompressed event to an IdEvent (only an 1d to represent the first part of the event) and push it to the compressed event queue
        (*compressed_events).push(eventToIdEvent(current_uncompressed_event, counter, x_multiplier, y_multiplier, polarity_multiplier));

        // Remove the uncompresssed event
        (*uncompressed_events).pop();
        counter++;

    }
}

// Obtain the correct instructions to compress the index of an id event, in case there is index compression
void compressEventsToIdEvents(CompressedFileHeader* compressed_event_file_configuration_pointer, queue<Event>* events_queue_pointer,queue<IdEvent>* id_events_queue_pointer, IndexCompressionAlgorithm index_compression_algorithm=IndexCompressionAlgorithm::NO_INDEX_COMPRESSION)
{
    // Change the index into a single int number

        // First find the range of the numbers
        int x_range=(*compressed_event_file_configuration_pointer).getXMax()+1-(*compressed_event_file_configuration_pointer).getXMin();
        int y_range=(*compressed_event_file_configuration_pointer).getYMax()+1-(*compressed_event_file_configuration_pointer).getYMin();
        int polarity_range = (*compressed_event_file_configuration_pointer).getPolarity()+1;

        // Then multiply them to create a custom numerical system, in this case x*720*2, y*2, polarity*1
        int x_multiplier = y_range * polarity_range;
        int y_multiplier = polarity_range;
        int polarity_multiplier = 1; // Polarity is our base case, so it must be 1

        // If value is 0 then it means that value has been compressed by the index algorithm, therefore doew not need to be represented

        // Apply the above multipliers to the idEvent queue
        switch (index_compression_algorithm){
            case NO_INDEX_COMPRESSION:
                x_multiplier = y_range * polarity_range;
                y_multiplier = polarity_range;
                polarity_multiplier = 1;
            break;
            case POLARITY_COMPRESSION:
                x_multiplier = y_range;
                y_multiplier = 1;
                polarity_multiplier = 0;
            break;
            case Y_COMPRESSION:
                x_multiplier = polarity_range;
                y_multiplier = 0;
                polarity_multiplier = 1;
            break;
            case X_COMPRESSION:
                x_multiplier = 0;
                y_multiplier = polarity_range;
                polarity_multiplier = 1;
            break;
            case Y_POLARITY_COMPRESSION:
                x_multiplier = 1;
                y_multiplier = 0;
                polarity_multiplier = 0;
            break;
            case X_POLARITY_COMPRESSION:
                x_multiplier = 0;
                y_multiplier = 1;
                polarity_multiplier = 0;
            break;
            case X_Y_COMPRESSION:
                x_multiplier = 0;
                y_multiplier = 0;
                polarity_multiplier = 1;
            break;
            case X_Y_POlARITY_COMPRESSION:
                x_multiplier = 0;
                y_multiplier = 0;
                polarity_multiplier = 0;
            break;
        }
        compressEventQueuetoIdEventQueue(events_queue_pointer,id_events_queue_pointer, x_multiplier, y_multiplier, polarity_multiplier);

}

// Compress both the index and timestamp as desired
void hybridIndexTimestampCompression(CompressedFileHeader* compressed_file_header_pointer, queue<Event>* input_events_queue_pointer, queue<Index>* index_queue_pointer, 
    queue<IdEvent>* output_events_queue_pointer, Index::IndexType last_indextype_sort, IndexCompressionAlgorithm index_compression_algorithm=IndexCompressionAlgorithm::NO_INDEX_COMPRESSION)
{
    cout<<"DEBUG: Starting hybridIndexTimestampCompression. Compression algorithm: "<<index_compression_algorithm<<"\n";
    cout<<"DEBUG: Input events size: "<<(*input_events_queue_pointer).size()<<"\n";
    
    queue<Event> sorted_events_queue;
    queue<Event>* sorted_events_queue_pointer = &sorted_events_queue;

    // Sort the events based on the index queue, will help distribute them for the timestamp delta compression
    sortIndexGeneralAlgortihm(input_events_queue_pointer,sorted_events_queue_pointer,index_queue_pointer,last_indextype_sort,compressed_file_header_pointer,index_compression_algorithm);
    
    cout<<"DEBUG: Returned from sortIndexGeneralAlgortihm. Index queue size: "<<(*index_queue_pointer).size()<<"\n";
    
    // Will enter this to make sure that the sorted events pointer is the ony one relevant from this point onwards. It may have been that input remains with information, so this is a way to guarentee it worked
    if((*sorted_events_queue_pointer).empty())
    {
        sorted_events_queue_pointer=input_events_queue_pointer;
    }
    

    int total_index_size = 0;
    int last_indextype_size = 0;

    cout<<"DEBUG: About to check if index queue is empty\n";
    
    // Check if index queue is empty after sorting
    if((*index_queue_pointer).empty())
    {
        cout<<"ERROR: Index queue is empty after sorting. Cannot proceed with compression.\n";
        (*compressed_file_header_pointer).log_entries.push("ERROR: Index queue is empty after sorting\n");
        return;
    }

    cout<<"DEBUG: Index queue not empty, about to access front()\n";
    cout<<"DEBUG: Index queue pointer address: "<<index_queue_pointer<<"\n";
    cout<<"DEBUG: Calling front() now...\n";
    fflush(stdout);
    
    // Loop throught the index queue, first we keep track of the Index Start entry as this indicates the code when to stop
    // This while loop is necessary because the index still includes the non-last-type entries, (ini case of the XYPol index compression, index still has the XY index entries, which will not be included in the file)
    Index current_index=(*index_queue_pointer).front();
    
    cout<<"DEBUG: Successfully got front index\n";

    // Push start index to the end of the queue
    (*index_queue_pointer).push(current_index);
    cout<<"DEBUG: Pushed index to back\n";
    (*index_queue_pointer).pop();
    cout<<"DEBUG: Popped front. Queue size now: "<<(*index_queue_pointer).size()<<"\n";

    total_index_size++;

    cout<<"DEBUG: About to enter while loop\n";
    
    // Find size of the index queue
    while (!(*index_queue_pointer).empty() && (*index_queue_pointer).front().index_type!=Index::START) 
    {  
        current_index=(*index_queue_pointer).front();
        (*index_queue_pointer).push(current_index);
        (*index_queue_pointer).pop();
        total_index_size++;
        if(current_index.index_type==last_indextype_sort)
            last_indextype_size++;
    }

    cout<<"DEBUG: Exited while loop. Index queue size: "<<(*index_queue_pointer).size()<<"\n";
    
    // Add number of index entries, as well as write it in the logs
    (*compressed_file_header_pointer).setNumberOfIndexEntries(last_indextype_size);
    
    cout<<"DEBUG: About to call indexToString with front()\n";
    (*compressed_file_header_pointer).log_entries.push("Total Index Size (for debug purposes): "+to_string(total_index_size)+" | "+"Last IndexType Size (entries to be written in the file): "+to_string(last_indextype_size)+" | "+indexToString((*index_queue_pointer).front())+"\n");

    cout<<"DEBUG: Called indexToString successfully\n";
    
    queue<Event> compressed_events_queue;
    queue<Event>* compressed_events_queue_pointer = &compressed_events_queue;

    cout<<"DEBUG: About to call deltaCompressEventQueue\n";
    deltaCompressEventQueue(index_queue_pointer,sorted_events_queue_pointer,compressed_events_queue_pointer,&Event::getTimestamp,&Event::setTimestamp,last_indextype_sort,compressed_file_header_pointer);

    cout<<"DEBUG: Returned from deltaCompressEventQueue. About to call compressEventsToIdEvents\n";
    
    //We use input again to recycle the queue
    compressEventsToIdEvents(compressed_file_header_pointer,compressed_events_queue_pointer,output_events_queue_pointer,index_compression_algorithm);
    
    cout<<"DEBUG: Returned from compressEventsToIdEvents. hybridIndexTimestampCompression complete.\n";
}

// Compress the id event queue without any index consideration
void deltaDecompressIdEventQueueByAttributeNoIndex(queue<IdEvent>* compressed_events,int (IdEvent::* get_function_pointer)(),void (IdEvent::* set_function_pointer)(int), queue<IdEvent>* decompressed_events, CompressedFileHeader* compressed_file_header_pointer)
{
     int base_value = (*compressed_file_header_pointer).getInitialTimestamp();
    if((*compressed_events).empty())
    {
        // TO DO, add error debugger. the file has no events
    }

    // Create current event
    IdEvent current_event;

    while(!(*compressed_events).empty())
    {
        // Get the next event
        current_event = (*compressed_events).front();
        (*compressed_events).pop();

        // Add the get value to the base value
        base_value += (current_event.*get_function_pointer)();;

        // Set the value in the event
        (current_event.*set_function_pointer)(base_value);

        // Add the compressed event to the compressed queue
        (*decompressed_events).push(current_event);

    }
}

// Compress the id event queue with  index consideration
void deltaDecompressIdEventQueueByAttributeWithIndex(queue<Index>* index_queue_pointer, queue<IdEvent>* compressed_events,int (IdEvent::* get_function_pointer)(),void (IdEvent::* set_function_pointer)(int), queue<IdEvent>* decompressed_events, CompressedFileHeader* compressed_file_header_pointer)
{
    int base_value = (*index_queue_pointer).front().getInitialTimestamp();
    int number_of_remaining_indexes = (*compressed_file_header_pointer).getNumberOfIndexEntries();
    if((*compressed_events).empty())
    {
        // TO DO, add error debugger. the file has no events
    }

    // Create current event
    IdEvent current_event;
    int current_index_event_counter = (*index_queue_pointer).front().getNumberOfElements();
    //number_of_remaining_indexes--;

    while(!(*compressed_events).empty())
    {
        if (current_index_event_counter>0)
        {
            // Get the next event
            current_event = (*compressed_events).front();
            (*compressed_events).pop();

            // Add the get value to the base value
            base_value += (current_event.*get_function_pointer)();;

            // Set the value in the event
            (current_event.*set_function_pointer)(base_value);

            // Add the compressed event to the compressed queue
            (*decompressed_events).push(current_event);

            current_index_event_counter--;
        }
        else
        {
            // To Do, error here just in case
            if(number_of_remaining_indexes>0)
            {
                (*index_queue_pointer).push((*index_queue_pointer).front());
                (*index_queue_pointer).pop();
            }
            base_value = (*index_queue_pointer).front().getInitialTimestamp();
            current_index_event_counter = (*index_queue_pointer).front().getNumberOfElements();

            if(number_of_remaining_indexes<0)
            {
                cout<<"Error somewhere, as the index number of elements does not match compressed events\n";
            }
            number_of_remaining_indexes--;

        }


    }
    // Realign the index queue, useful for later when decompressing into events
    while(number_of_remaining_indexes>0)
    {
        (*index_queue_pointer).push((*index_queue_pointer).front());
        (*index_queue_pointer).pop();
        number_of_remaining_indexes--;
    }

}

// Identify if the compression is with index or without index
void deltaDecompressIdEventQueueByAttribute(queue<Index>* index_queue_pointer,queue<IdEvent>* compressed_events,int (IdEvent::* get_function_pointer)(),void (IdEvent::* set_function_pointer)(int), queue<IdEvent>* decompressed_events, CompressedFileHeader* compressed_file_header_pointer)
{
    if ((*compressed_file_header_pointer).getIsIndexEncoded())
    {
        deltaDecompressIdEventQueueByAttributeWithIndex(index_queue_pointer,compressed_events,get_function_pointer,set_function_pointer,decompressed_events,compressed_file_header_pointer);
    }
    else
    {
        deltaDecompressIdEventQueueByAttributeNoIndex(compressed_events,get_function_pointer,set_function_pointer,decompressed_events,compressed_file_header_pointer);
    }
}

// Histogram analysis for the dictionary compression, find the optimal values for comrpession
void dictionaryCompressionHistogramAnalysis(int* event_distribution_array, CompressedFileHeader* compressed_file_header_pointer)
{
    //Output will be stored in the comrpessed file header
    const int timestamp_bit_size = (*compressed_file_header_pointer).getEventTimestampSize();
    int timestamp_array[timestamp_bit_size] = {};
    int uncompressed_events[timestamp_bit_size] = {};
    int total_sum[timestamp_bit_size] = {};
    int minimum_index = 0;

    for (int i = 0; i<timestamp_bit_size; i++)
    {
        int value_to_add_to_array = 0;
        for (int j = 0; j<timestamp_bit_size-i; j++)
        {
            // Grab the values from the start of the array to the end, but each iteration stop one earlier
            value_to_add_to_array+=event_distribution_array[j];
        }
        uncompressed_events[i]=value_to_add_to_array;
        timestamp_array[i]=timestamp_bit_size-i;

    }

    // Event size is simply the bits needed to represent the number of events, necessary as we will append this number to the id_event
    int number_of_events = (*compressed_file_header_pointer).getNumberOfEvents();
    int id_bit_size = findMinimumBitsNeeded(number_of_events);

    int events_total_bit_size  = 0;
    int header_total_bit_size  = 0;


    // Total sum analysis
    for (int i = 0; i<timestamp_bit_size; i++)
    {
        // Get the total size of the events
        events_total_bit_size = uncompressed_events[i] * timestamp_array[i];

        // Get the total size of the header
        // First find the size of each header entry, which would be the largest timestamp + a unique id, and multiply by the number of compressed events (uncompressed-total)
        header_total_bit_size = (timestamp_bit_size+id_bit_size) * (number_of_events -  uncompressed_events[i]);
        // Get the total sum
        total_sum[i] = events_total_bit_size + header_total_bit_size;
    }

    string log_dictionary_distribution = "Dictionary Distribution array: ";
    //cout<<"Finding minimum value:\n";
    for (int i = 0; i<timestamp_bit_size; i++)
    {
        log_dictionary_distribution+=to_string(total_sum[i])+",";

        if(total_sum[i]<total_sum[minimum_index])
            minimum_index = i;
    }
    (*compressed_file_header_pointer).log_entries.push(log_dictionary_distribution+"\n");
    (*compressed_file_header_pointer).log_entries.push("Minimum value: "+to_string(total_sum[minimum_index])+" for "+to_string(timestamp_array[minimum_index])+" bits"+" total number of dictionary encoded events: "+to_string(number_of_events -  uncompressed_events[minimum_index])+"\n");

    // If the minimum index is not the default then apply the dictionary encoded, 0 means no dictionary encoding was the optimal solution
    if(minimum_index!=0)
    {
        (*compressed_file_header_pointer).log_entries.push("The file will be dictionary encoded\n");
        (*compressed_file_header_pointer).setIsDictionaryEncoded(1);
        (*compressed_file_header_pointer).setDictionaryEncodingTimestampBitSize(timestamp_array[minimum_index]);
        (*compressed_file_header_pointer).setDictionaryEncodingIdBitSize(id_bit_size);
    }
    // The file will not be dictionary encoded
    else
    {
        
        (*compressed_file_header_pointer).log_entries.push("The file will be not dictionary encoded\n");
        (*compressed_file_header_pointer).setIsDictionaryEncoded(0);
        (*compressed_file_header_pointer).setDictionaryEncodingTimestampBitSize(timestamp_bit_size);
        (*compressed_file_header_pointer).setDictionaryEncodingIdBitSize(id_bit_size);
    }

}

// Add the encoding instruction to each event to know which algorithm to perform
void addEncodingInstructionToIdEvent(queue<IdEvent>* id_event_queue_pointer,CompressedFileHeader* compressed_file_header_pointer)
{
    // Initialize variables
            int number_of_events = (*compressed_file_header_pointer).getNumberOfEvents();
            int counter = 0;
                //Find the maximum size for regular event, for 5 bits it should be 31
            int max_value_for_dictionary_encoding = pow(2,(*compressed_file_header_pointer).getDictionaryEncodingTimestampBitSize())-1;
            int minimum_value_for_huffman_encoding = pow(2,(*compressed_file_header_pointer).getHuffmanEncodingTimestampBitSize())-1;

            IdEvent current_event = (*id_event_queue_pointer).front();
            int counter_1 = 0; // For dictionary encoding
            int counter_2 = 0; // For huffman long encoding
            int counter_3 = 0; // For huffman short encoding

            // The instructions are initially set to none, as we will check if the file is actually going to use them in the next few lines
            IdEvent::CompressionInstruction dictionary_instruction = IdEvent::CompressionInstruction::NONE;
            IdEvent::CompressionInstruction huffman_long_timestamp = IdEvent::CompressionInstruction::NONE;
            IdEvent::CompressionInstruction huffman_short_timestamp = IdEvent::CompressionInstruction::NONE;

            // If the file is going to use dictionary encoding, then add the instruction
            if((*compressed_file_header_pointer).getIsDictionaryEncoded())
            {
                dictionary_instruction = IdEvent::CompressionInstruction::DICTIONARY_ADD_TO_INDEX;
            }
            // If the file is going to use huffman compression, then add the instruction
            if((*compressed_file_header_pointer).getIsHuffmanEncoded())
            {
                huffman_long_timestamp = IdEvent::CompressionInstruction::HUFFMAN_LONG_EVENT;
                huffman_short_timestamp = IdEvent::CompressionInstruction::HUFFMAN_SHORT_EVENT;
            }


    // Add the encoding instruction to each of the events
            while (counter < number_of_events)
            {
                current_event = (*id_event_queue_pointer).front();

                if(current_event.getTimestamp()>max_value_for_dictionary_encoding)
                {
                    // Use Dictionary Encoding
                    current_event.setCompressionInstruction(dictionary_instruction);
                    counter_1++;
                }
                else if (current_event.getTimestamp()>minimum_value_for_huffman_encoding)
                {
                    // Use Huffman Long Event Encoding
                    current_event.setCompressionInstruction(huffman_long_timestamp);
                    counter_2++;

                }
                else
                {
                    // Use Dictionary Encoding
                    current_event.setCompressionInstruction(huffman_short_timestamp);
                    counter_3++;
                }


                (*id_event_queue_pointer).push(current_event);
                (*id_event_queue_pointer).pop();
                counter++;
                

            }
    cout<<"\n";
    (*compressed_file_header_pointer).log_entries.push("Verify sum | dictionary: "+to_string(counter_1)+" huffman long: "+to_string(counter_2)+" huffman_short: "+to_string(counter_3)+"\n");
}

// Identify the optimal values for huffman comrpession
void huffmanCompressionHistogramAnalysis(int* event_distribution_array, CompressedFileHeader* compressed_file_header_pointer)
{
    // Initialize variables
            const int huffman_timestamp_bit_size = (*compressed_file_header_pointer).getDictionaryEncodingTimestampBitSize();
            // The +1 is necessary as if not it would ignore the last element
            const int huffman_timestamp_bit_size_with_trigger = huffman_timestamp_bit_size + 1;
            int timestamp_array[huffman_timestamp_bit_size] = {};
            // Short events are events that will be compressed, but will receive 1 additional bit for the trigger
            int short_events[huffman_timestamp_bit_size] = {};
            int total_sum[huffman_timestamp_bit_size] = {};
            int minimum_index = 0;
            int trigger_size = 1;

    // Loop and add the event distribution array to create the short events distribution array and the timestamp size array
            //We tecnically skp checking if all are long events, as this will result in the same as if all are short events, it always ends up in more bits anyways
            for (int i = 0; i<huffman_timestamp_bit_size; i++)
            {
                int value_to_add_to_array = 0;
                for (int j = 0; j<huffman_timestamp_bit_size-i; j++)
                {
                    // Grab the values from the start of the array to the end, but each iteration stop one earlier
                    value_to_add_to_array+=event_distribution_array[j];
                }
                short_events[i]=value_to_add_to_array;
                timestamp_array[i]=huffman_timestamp_bit_size_with_trigger-i;
            }

    // Total sum of bits analysis
            // Event size is simply the bits needed to represent the number of events, necessary as we will append this number to the id_event
            int number_of_events = short_events[0];
            int short_events_total_bit_size  = 0;
            int long_events_total_bit_size  = 0;

            for (int i = 0; i<huffman_timestamp_bit_size; i++)
            {
                // Get the total size of the events
                short_events_total_bit_size = short_events[i] * timestamp_array[i];

                // Get the total size of the header
                // First find the size of each header entry, which would be the largest timestamp + a unique id, and multiply by the number of compressed events (uncompressed-total)
                long_events_total_bit_size = (huffman_timestamp_bit_size_with_trigger) * (number_of_events -  short_events[i]);
                // Get the total sum
                total_sum[i] = short_events_total_bit_size + long_events_total_bit_size;
            }

    // Log Entries as output
            string log_dictionary_distribution = "Huffman Distribution Array: ";

            for (int i = 0; i<huffman_timestamp_bit_size; i++)
            {
                log_dictionary_distribution+=to_string(total_sum[i])+",";

                if(total_sum[i]<total_sum[minimum_index])
                    minimum_index = i;
            }
            (*compressed_file_header_pointer).log_entries.push(log_dictionary_distribution+"\n");
            (*compressed_file_header_pointer).log_entries.push("Minimum value: "+to_string(total_sum[minimum_index])+" for "+to_string(timestamp_array[minimum_index])+" bits, short huffman events "+to_string(short_events[minimum_index])+", long huffman events "+to_string(number_of_events -  short_events[minimum_index])+"\n");

    // If the minimum index is not the default then apply the dictionary encoded, 0 means no dictionary encoding was the optimal solution
            if(minimum_index!=0)
            {
                (*compressed_file_header_pointer).log_entries.push("Because the minimum value is not 0, we will do huffman encoding\n");
                (*compressed_file_header_pointer).setIsHuffmanEncoded(1);
                (*compressed_file_header_pointer).setHuffmanEncodingTimestampBitSize(timestamp_array[minimum_index]-trigger_size);
                (*compressed_file_header_pointer).setHuffmanTriggerSize(1);
            }
            else
            {
                (*compressed_file_header_pointer).log_entries.push("The minimum value is 0 therefore huffman encoding will not save size, as such it will not be huffman encoded\n");
                (*compressed_file_header_pointer).setIsHuffmanEncoded(0);
                (*compressed_file_header_pointer).setHuffmanEncodingTimestampBitSize(timestamp_array[minimum_index]-trigger_size);
                (*compressed_file_header_pointer).setHuffmanTriggerSize(0);
            }
}

// Generate all the hitogram analysis
void generateHistogramAnalysisIdEvents(queue<IdEvent>* compressed_events_pointer,int bucket_analysis_size,CompressedFileHeader* compressed_file_header_pointer,int* timestamp_buckets)
{
    // Find the max values to create the histogram array, have to add one because values may be zero
            int timestamp_length = findMaxAttribute(compressed_events_pointer,(*compressed_file_header_pointer).getNumberOfEvents(),&IdEvent::getTimestamp)+1;
            int index_id_length = findMaxAttribute(compressed_events_pointer,(*compressed_file_header_pointer).getNumberOfEvents(),&IdEvent::getIndexId)+1; 

        

    // Find the Minimum bits needed
            int index_id_bucket_length = findMinimumBitsNeeded(index_id_length);
            int timestamp_bucket_length = findMinimumBitsNeeded(timestamp_length);

            (*compressed_file_header_pointer).setEventIndexSize(index_id_bucket_length);
            (*compressed_file_header_pointer).setEventTimestampSize(timestamp_bucket_length);        
        
            if(index_id_length==1)
            {
                (*compressed_file_header_pointer).log_entries.push("If the index_id_length is 1, it means that no actual id values are present, thus index size is set to 0");
                (*compressed_file_header_pointer).setEventIndexSize(0);
            }



    // Create the bucket array and push it to the log entries
            eventQueueToBucket(compressed_events_pointer,(*compressed_file_header_pointer).getNumberOfEvents(),timestamp_buckets,bucket_analysis_size);
            string log_timestamp_buckets="Event Distribution Array: ";
            for(int i = 0; i<bucket_analysis_size-1; i++)
            {
                log_timestamp_buckets+=to_string(timestamp_buckets[i])+",";
            }

            (*compressed_file_header_pointer).log_entries.push(log_timestamp_buckets+"\n");

    // Output variables
            (*compressed_file_header_pointer).log_entries.push("Index size: "+to_string((*compressed_file_header_pointer).getEventIndexSize())+", Timestamp size: "+to_string((*compressed_file_header_pointer).getEventTimestampSize())+'\n');
}

// Generate the histogram analysis for Index
void generateHistogramAnalysisIndex(queue<Index>* index_queue_pointer, Index::IndexType last_indextype_sort, CompressedFileHeader* compressed_file_header_pointer)
{
    cout<<"DEBUG: generateHistogramAnalysisIndex called. Index queue size: "<<(*index_queue_pointer).size()<<"\n";
    
    //Check here for the last indextype sort for each use the total index size somewhere
            int index_number_of_events_max = findMaxAttribute(index_queue_pointer,&Index::getNumberOfElements)+1;
            cout<<"DEBUG: After first findMaxAttribute. Index queue size: "<<(*index_queue_pointer).size()<<"\n";
            
            int index_initial_timestamp_max = findMaxAttribute(index_queue_pointer,&Index::getInitialTimestamp)+1;
            cout<<"DEBUG: After second findMaxAttribute. Index queue size: "<<(*index_queue_pointer).size()<<"\n";

    // Find the Minimum bits needed
            int index_number_of_events_bits = findMinimumBitsNeeded(index_number_of_events_max);
            int index_initial_timestamp_bits = findMinimumBitsNeeded(index_initial_timestamp_max);
            int total_number_of_entries = (*compressed_file_header_pointer).getNumberOfIndexEntries();
            int total_index_header_bits = 0;

    // If the file will be index encoded
            if((*compressed_file_header_pointer).getIsIndexEncoded()!=0)
            {
                (*compressed_file_header_pointer).log_entries.push("File will be index encoded\n");

                (*compressed_file_header_pointer).setIndexNumberOfEventSize(index_number_of_events_bits);
                (*compressed_file_header_pointer).setIndexInitialTimestampSize(index_initial_timestamp_bits);
                total_index_header_bits = (index_number_of_events_bits + index_initial_timestamp_bits) * total_number_of_entries;
                (*compressed_file_header_pointer).log_entries.push("Index number of event bits: "+to_string(index_number_of_events_bits)+" | Index initial timestamp: "+to_string(index_initial_timestamp_bits)+"\n");
                
            }

    // If the file will NOT be index encoded
            else
            {
                (*compressed_file_header_pointer).log_entries.push("File will not be index encoded\n");
                (*compressed_file_header_pointer).setIndexNumberOfEventSize(0);
                (*compressed_file_header_pointer).setIndexInitialTimestampSize(0);
            }

    // Write total index size to the logs
            (*compressed_file_header_pointer).log_entries.push("Index total size: "+to_string(total_index_header_bits)+'\n');
}

// Decomrpess Id events into events, without consideration of index
void decompressIdEventToEventNoIndex(std::queue<IdEvent>* input_id_event_queue, std::queue<Event>* output_event_queue, CompressedFileHeader* compressed_file_header_pointer)
{
    int x_multiplier=(*compressed_file_header_pointer).getXMax()+1-(*compressed_file_header_pointer).getXMin();
    int y_multiplier=(*compressed_file_header_pointer).getYMax()+1-(*compressed_file_header_pointer).getYMin();
    int polarity_multiplier = (*compressed_file_header_pointer).getPolarity()+1;


    //WORKING HERE 2
    int counter=0;
    if((*input_id_event_queue).empty())
    {
        // TO DO, add error debugger. the file has no events
    }

    // Find initial event
    IdEvent current_uncompressed_id_event = (*input_id_event_queue).front();

    while(!(*input_id_event_queue).empty())
    {
        //cout<<" counter: "<<counter;
        // get the current uncompressed event
        current_uncompressed_id_event = (*input_id_event_queue).front();

        // transform the uncompressed event to an IdEvent (only an 1d to represent the first part of the event) and push it to the compressed event queue
        (*output_event_queue).push(idEventToEvent(current_uncompressed_id_event, x_multiplier, y_multiplier, polarity_multiplier));
        //cout<<" "<<idEventToString((*compressed_events).back());

        
        // Remove the uncompresssed event
        (*input_id_event_queue).pop();
        counter++;

    }
}

// The counter array basically indicates if you increase pol y or x for the next index, 
void increaseCounterArray(int* index_header_multiplier_array, int* index_header_counter_array, int size_of_array)
{
    int current_index_to_count = size_of_array-1;
    index_header_counter_array[current_index_to_count]++;
    while(current_index_to_count>=0)
    {
        if (index_header_counter_array[current_index_to_count]>index_header_multiplier_array[current_index_to_count])
        {

            index_header_counter_array[current_index_to_count] = 0;
            current_index_to_count--;
            index_header_counter_array[current_index_to_count]++;

        }
        else
            break;
    }
}

// Decompress Id events into events, with consideration of index
void decompressIdEventToEventWithIndex(std::queue<IdEvent>* input_id_event_queue, std::queue<Index>* index_queue_pointer, std::queue<Event>* output_event_queue, CompressedFileHeader* compressed_file_header_pointer)
{
    int index_entries = 3;
    int x_range=(*compressed_file_header_pointer).getXMax()+1-(*compressed_file_header_pointer).getXMin();
    int y_range=(*compressed_file_header_pointer).getYMax()+1-(*compressed_file_header_pointer).getYMin();
    int polarity_range = (*compressed_file_header_pointer).getPolarity()+1;

    int x_multiplier = 0;
    int y_multiplier = 0;
    int polarity_multiplier = 0;

    int event_index_multiplier_array [index_entries] = {0,0,0}; // X, Y, Polarity 


    int index_header_multiplier_array [index_entries] = {0,0,0}; // X, Y, Polarity 

    int index_header_counter_array [index_entries] = {0,0,0}; // X, Y, Polarity 

    IndexCompressionAlgorithm compression_algorithm = (IndexCompressionAlgorithm)(*compressed_file_header_pointer).getIsIndexEncoded();

    switch(compression_algorithm)
    {
        case(IndexCompressionAlgorithm::NO_INDEX_COMPRESSION):
            event_index_multiplier_array[0] = x_range;
            event_index_multiplier_array[1] = y_range;
            event_index_multiplier_array[2] = polarity_range;

            index_header_multiplier_array[0] = 0;
            index_header_multiplier_array[1] = 0;
            index_header_multiplier_array[2] = 0;
        break;
        case(IndexCompressionAlgorithm::POLARITY_COMPRESSION):
            event_index_multiplier_array[0] = x_range;
            event_index_multiplier_array[1] = y_range;
            event_index_multiplier_array[2] = 0;

            index_header_multiplier_array[0] = 0;
            index_header_multiplier_array[1] = 0;
            index_header_multiplier_array[2] = polarity_range-1;
        break;
        case(IndexCompressionAlgorithm::Y_COMPRESSION):
            event_index_multiplier_array[0] = x_range;
            event_index_multiplier_array[1] = 0;
            event_index_multiplier_array[2] = polarity_range;

            index_header_multiplier_array[0] = 0;
            index_header_multiplier_array[1] = y_range-1;
            index_header_multiplier_array[2] = 0;
        break;
        case(IndexCompressionAlgorithm::Y_POLARITY_COMPRESSION):
            event_index_multiplier_array[0] = x_range;
            event_index_multiplier_array[1] = 0;
            event_index_multiplier_array[2] = 0;

            index_header_multiplier_array[0] = 0;
            index_header_multiplier_array[1] = y_range-1;
            index_header_multiplier_array[2] = polarity_range-1;
        break;
        case(IndexCompressionAlgorithm::X_COMPRESSION):
            event_index_multiplier_array[0] = 0;
            event_index_multiplier_array[1] = y_range;
            event_index_multiplier_array[2] = polarity_range;

            index_header_multiplier_array[0] = x_range-1;
            index_header_multiplier_array[1] = 0;
            index_header_multiplier_array[2] = 0;
        break;
        case(IndexCompressionAlgorithm::X_POLARITY_COMPRESSION):
            event_index_multiplier_array[0] = 0;
            event_index_multiplier_array[1] = y_range;
            event_index_multiplier_array[2] = 0;

            index_header_multiplier_array[0] = x_range-1;
            index_header_multiplier_array[1] = 0;
            index_header_multiplier_array[2] = polarity_range-1;
        break;
        case(IndexCompressionAlgorithm::X_Y_COMPRESSION):
            event_index_multiplier_array[0] = 0;
            event_index_multiplier_array[1] = 0;
            event_index_multiplier_array[2] = polarity_range;

            index_header_multiplier_array[0] = x_range-1;
            index_header_multiplier_array[1] = y_range-1;
            index_header_multiplier_array[2] = 0;
        break;
        case(IndexCompressionAlgorithm::X_Y_POlARITY_COMPRESSION):
            event_index_multiplier_array[0] = 0;
            event_index_multiplier_array[1] = 0;
            event_index_multiplier_array[2] = 0;

            index_header_multiplier_array[0] = x_range-1;
            index_header_multiplier_array[1] = y_range-1;
            index_header_multiplier_array[2] = polarity_range-1;
        break;
        default:
            event_index_multiplier_array[0] = x_range;
            event_index_multiplier_array[1] = y_range;
            event_index_multiplier_array[2] = polarity_range;

            index_header_multiplier_array[0] = 0;
            index_header_multiplier_array[1] = 0;
            index_header_multiplier_array[2] = 0;
        break;
    }


    //WORKING HERE 2
    int counter=0;
    if((*input_id_event_queue).empty())
    {
        // TO DO, add error debugger. the file has no events
    }

    // Find initial event
    IdEvent current_uncompressed_id_event = (*input_id_event_queue).front();
    Index current_index = (*index_queue_pointer).front();

    int current_index_event_counter = 0;
    int current_index_counter = 0;
    int total_index_size = (*index_queue_pointer).size();

    while(current_index_counter<total_index_size)
    {
        current_index = (*index_queue_pointer).front();

        // if it is still in the same index
        while (current_index_event_counter<current_index.getNumberOfElements())
        {
            //cout<<" counter: "<<counter;
            // get the current uncompressed event
            current_uncompressed_id_event = (*input_id_event_queue).front();

            // transform the uncompressed event to an IdEvent (only an 1d to represent the first part of the event) and push it to the compressed event queue
            Event event_to_be_added = idEventToEvent(current_uncompressed_id_event, event_index_multiplier_array[0], event_index_multiplier_array[1], event_index_multiplier_array[2]);
            event_to_be_added.setX(event_to_be_added.getX()+index_header_counter_array[0]);
            event_to_be_added.setY(event_to_be_added.getY()+index_header_counter_array[1]);
            event_to_be_added.setPolarity(event_to_be_added.getPolarity()+index_header_counter_array[2]);

            (*output_event_queue).push(event_to_be_added);
            //cout<<" "<<idEventToString((*compressed_events).back());

            
            // Remove the uncompresssed event
            (*input_id_event_queue).pop();
            counter++;
            current_index_event_counter++;
        }

        current_index_event_counter = 0;
        current_index_counter++;
        (*index_queue_pointer).push(current_index);
        (*index_queue_pointer).pop();
        current_index = (*index_queue_pointer).front();

        cout<<"KAPING "<<index_header_multiplier_array[2]<<"\n";
        cout<<"KAPAW "<<index_header_counter_array[2]<<"\n";

        increaseCounterArray(index_header_multiplier_array, index_header_counter_array, index_entries);



    }
}

// Decompress id events to events, and choose if there is index or without index
void decompressIdEventToEvent(std::queue<IdEvent>* input_id_event_queue, std::queue<Index>* index_queue_pointer, std::queue<Event>* output_event_queue, CompressedFileHeader* compressed_file_header_pointer)
{
    if((*compressed_file_header_pointer).getIsIndexEncoded())
    {
        decompressIdEventToEventWithIndex(input_id_event_queue,index_queue_pointer,output_event_queue,compressed_file_header_pointer);
    }
    else
    {
        decompressIdEventToEventNoIndex(input_id_event_queue,output_event_queue,compressed_file_header_pointer);
    }
}


#endif 