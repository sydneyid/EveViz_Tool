#pragma once
#ifndef EVENT_H
#define EVENT_H

// Events have each value completely separated. with an uncompressed timestamp useful for dictionary encoding
class Event
{
    private:
    // Useful for dictionary encoding
    int uncompressed_timestamp;

    public:
        int x;
        int y;
        int polarity;
        int timestamp;


        // Get Methods
        int getTimestamp()
        {
            return timestamp;
        }
        int getUncompressedTimestamp()
        {
            return uncompressed_timestamp;
        }
        int getX()
        {
            return x;
        }
        int getY()
        {
            return y;
        }
        int getPolarity()
        {
            return polarity;
        }

        //Set Mehtods
        void setTimestamp(int input_timestamp)
        {
            timestamp =  input_timestamp;
        }
        void setX(int input_x)
        {
            x =  input_x;
        }
        void setY(int input_y)
        {
            y =  input_y;
        }
        void setPolarity(int input_polarity)
        {
            polarity =  input_polarity;
        }
        void setUncompressedTimestamp(int input_uncompressed_timestamp)
        {
            uncompressed_timestamp =  input_uncompressed_timestamp;
        }

        Event(int input_x, int input_y, int input_polarity, int input_timestamp)
        : x{input_x}
        , y{input_y}
        , polarity{input_polarity}
        , timestamp{input_timestamp}
        , uncompressed_timestamp{input_timestamp}
        {}
        Event()
        {}
};

// Id events combine x y and polarity into a single index
class IdEvent
{
    private:
    // Useful for dictionary encoding
    int uncompressed_timestamp;
    int event_id;

    public:

        int index_id;
        int timestamp;

        enum CompressionInstruction{
            NONE,
            HUFFMAN_SHORT_EVENT,
            HUFFMAN_LONG_EVENT,
            DICTIONARY_ADD_TO_INDEX
        };
        CompressionInstruction compression_instruction = NONE;


        // Get Methods
        int getEventId()
        {
            return event_id;
        }
        int getTimestamp()
        {
            return timestamp;
        }
        int getUncompressedTimestamp()
        {
            return uncompressed_timestamp;
        }
        int getIndexId()
        {
            return index_id;
        }
        CompressionInstruction getCompressionInstruction()
        {
            return compression_instruction;
        }

        //Set Mehtods
        void setIndexId(int input_index_id)
        {
            index_id =  input_index_id;
        }
         void setEventId(int input_event_id)
        {
            event_id =  input_event_id;
        }

        //Set Mehtods
        void setTimestamp(int input_timestamp)
        {
            timestamp =  input_timestamp;
        }
        void setUncompressedTimestamp(int input_uncompressed_timestamp)
        {
            uncompressed_timestamp =  input_uncompressed_timestamp;
        }

        void setCompressionInstruction(CompressionInstruction input_compression_instruction)
        {
            compression_instruction =  input_compression_instruction;
        }

        IdEvent(int input_event_id=0, int input_index_id=0, int input_timestamp=0, int input_uncompressed_timestamp=0)
        : event_id{input_event_id}
        , index_id{input_index_id}
        , timestamp{input_timestamp}
        , uncompressed_timestamp{input_uncompressed_timestamp}
        {}
};



#endif