#pragma once
#ifndef EVENT_MANAGER_H
#define EVENT_MANAGER_H
#include <string>
#include <queue>
using namespace std;

#include "Event.h"

// Receive an event and output a string
string eventToString(Event event_to_convert, char value_separator =' ')
{
    // Order the different parameters of the event, separate them with the appropriate separator, and write them with a line break at the end
    string return_string=to_string(event_to_convert.x)+value_separator+to_string(event_to_convert.y)+value_separator+to_string(event_to_convert.polarity)+value_separator+to_string(event_to_convert.timestamp);
    return return_string;
}

// Receive an idevent and output a string
string idEventToString(IdEvent id_event_to_convert, char value_separator =' ')
{
    // Order the different parameters of the event, separate them with the appropriate separator, and write them with a line break at the end
    string return_string=to_string(id_event_to_convert.getEventId())+value_separator+to_string(id_event_to_convert.getIndexId())+value_separator+to_string(id_event_to_convert.getTimestamp())+"\n";
    return return_string;
}

// Receive an event and output a string with a specified file format
string eventToFileFormat(Event event_to_convert, char value_separator =' ')
{
    // Order the different parameters of the event, separate them with the appropriate separator, and write them with a line break at the end
    string return_string=to_string(event_to_convert.x)+value_separator+to_string(event_to_convert.y)+value_separator+to_string(event_to_convert.polarity)+value_separator+to_string(event_to_convert.timestamp)+"\n";
    return return_string;
}

// Generate a string for file comparison, useful for debugging
string eventToFileComparisonFormat(Event event_to_convert, char value_separator =' ')
{
    // Order the different parameters of the event, separate them with the appropriate separator, and write them with a line break at the end
    string return_string=to_string(event_to_convert.x)+value_separator+to_string(event_to_convert.y)+value_separator+to_string(event_to_convert.polarity)+value_separator+to_string(event_to_convert.timestamp);
    return return_string;
}

// Id event to file format is only useful for debugging purposes
string idEventToFileFormat(IdEvent id_event_to_convert, char value_separator =' ')
{
    // Order the different parameters of the event, separate them with the appropriate separator, and write them with a line break at the end
    string return_string=to_string(id_event_to_convert.getIndexId())+value_separator+to_string(id_event_to_convert.getTimestamp());
    return return_string;
}

// This function This function receives a vecgtor of string tokens, it then builds and returns the event. 
// Needs x_min and y_min as it will make them into zero useful for debugging purposes
Event stringVectorToEvent(vector<string> tokens, int x_min, int y_min)
{
    
   string time_string = tokens.back();
   int time_stamp=stoi(time_string);
   tokens.pop_back();

   string polarity_string = tokens.back();

    int polarity =stoi(polarity_string);
    if (polarity!=1){
        polarity=0;
    }
    
    tokens.pop_back();


    string y_string = tokens.back();
    int y_coordinates=stoi(y_string)-y_min;
    tokens.pop_back();

    string x_string = tokens.back();
    int x_coordinates=stoi(x_string)-x_min;
    tokens.pop_back();

    Event *event_to_return = new Event(x_coordinates,y_coordinates,polarity, time_stamp);

    return *event_to_return;
}


// Code enters this function
// This function receives a string and generates an Event Object
Event stringToEvent(string line_to_convert, int x_min, int y_min, char value_separator)
{
    // Tokens is a vector list of strings which represents the separated values of the original string event
    vector<string> tokens;
    // Used for loop counting and finding the value separators
    size_t pos = 0;
    // Token refers to the current string that is being built which represents a parameter of the Event
    string token;

    // While loop will go through the string, cut it using substring, and push the values to tokens
    while ((pos = line_to_convert.find(value_separator)) != string::npos) {
        token = line_to_convert.substr(0, pos);
        tokens.push_back(token);
        line_to_convert.erase(0, pos + 1);
    }

    // Final residue is also added
    tokens.push_back(line_to_convert);

    //
    Event event_to_return=stringVectorToEvent(tokens, x_min, y_min);
    // cout<<eventToString(event_to_return, value_separator);
    
    return event_to_return;
}

// Code enters this function
//We can't return an array normally in c++, so we will return a pointer to the array
void stringToEventQueue(queue<string>* raw_events,queue<Event>* events, int x_min, int y_min, char value_separator)
{
    int event_counter=0;
    while (!(*raw_events).empty()) {
        string current_event_string =(*raw_events).front();
        Event current_event=stringToEvent(current_event_string,x_min,y_min,value_separator);
        (*events).push(current_event);
        event_counter++;
        
        (*raw_events).pop();
    }
}

// Code enters this function
IdEvent eventToIdEvent(Event event_to_be_compressed, int event_id, int x_multiplier, int y_multiplier, int polarity_multiplier)
{
    // Basically the multiplier will allow us to sum the values without losing data
    // An example of multipliers would be x_multiplier = 1280*720*2, y_multiplier = 720*2, polarity_multiplier = 2 | x_multiplier = x_size * y_size * pol_size, y_multiplier = y_size * pol_size, pol_multiplier = pol_zize
    int compressed_index_id = x_multiplier*event_to_be_compressed.getX()+y_multiplier*event_to_be_compressed.getY()+polarity_multiplier*event_to_be_compressed.getPolarity();
    return IdEvent(event_id, compressed_index_id, event_to_be_compressed.getTimestamp(), event_to_be_compressed.getUncompressedTimestamp());
}

Event idEventToEvent(IdEvent event_to_be_decompressed, int x_multiplier, int y_multiplier, int polarity_multiplier)
{
    int event_index_value=event_to_be_decompressed.getIndexId();
    int x_value = 0;
    int y_value = 0;
    int polarity_value=0;

    // May be zero if it polarity was compressed with index
    if (polarity_multiplier!=0)
    {
        polarity_value = event_index_value % polarity_multiplier;
        event_index_value -= polarity_value;
        event_index_value /= polarity_multiplier;
    }
    
    if (y_multiplier!=0)
    {
        y_value = event_index_value % (y_multiplier);
        event_index_value -= y_value;
        event_index_value /= y_multiplier;
    }
    
    if (x_multiplier!=0)
    {
        x_value = event_index_value % (x_multiplier);
        event_index_value -= x_value;
    }

    // Basically the multiplier will allow us to sum the values without losing data
    // An example of multipliers would be x_multiplier = 1280*720*2, y_multiplier = 720*2, polarity_multiplier = 2 | x_multiplier = x_size * y_size * pol_size, y_multiplier = y_size * pol_size, pol_multiplier = pol_zize
    //int compressed_index_id = x_multiplier*event_to_be_compressed.getX()+y_multiplier*event_to_be_compressed.getY()+polarity_multiplier*event_to_be_compressed.getPolarity();
    return Event(x_value, y_value, polarity_value, event_to_be_decompressed.getTimestamp());
}

// Get methods for the event
int getTimestamp(Event input_event)
{
    return input_event.timestamp;
}

int getX(Event input_event)
{
    return input_event.x;
}

int getY(Event input_event)
{
    return input_event.y;
}

int getPolarity(Event input_event)
{
    return input_event.polarity;
}

#endif