#pragma once
#ifndef INDEX_H
#define INDEX_H

// Index indicates how many events are in each index (xypol coordinate)
class Index
{
    private:
    int initial_timestamp;
    int value;
    int number_of_elements; 


    public:
        enum IndexType{
            START,
            X_POSITION,
            Y_POSITION,
            POLARITY
        };
        IndexType index_type;

        Index()
        : index_type{IndexType::START}
        , value{0}
        //, initial_timestamp{input_initial_index}
        , number_of_elements{0}
        {}

        Index(IndexType input_index_type, int input_value, /*int input_initial_index,*/ int input_number_of_elements)
        : index_type{input_index_type}
        , value{input_value}
        //, initial_timestamp{input_initial_index}
        , number_of_elements{input_number_of_elements}
        {}

        Index(IndexType input_index_type, int input_value, int input_initial_index, int input_number_of_elements)
        : index_type{input_index_type}
        , value{input_value}
        , initial_timestamp{input_initial_index}
        , number_of_elements{input_number_of_elements}
        {}

        int getInitialTimestamp()
        {
            return initial_timestamp;
        }
        void setInitialTimestamp(int input_initial_timestamp)
        {
            initial_timestamp = input_initial_timestamp;
        }

        int getValue()
        {
            return value;
        }
        void setValue(int input_value)
        {
            value = input_value;
        }

        int getNumberOfElements()
        {
            return number_of_elements;
        }
        void setNumberOfElements(int input_number_of_elements)
        {
            number_of_elements = input_number_of_elements;
        }


};

#endif