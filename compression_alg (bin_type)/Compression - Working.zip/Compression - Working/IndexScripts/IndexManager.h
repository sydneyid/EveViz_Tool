#pragma once
#ifndef INDEXMANAGER_H
#define INDEXMANAGER_H
#include "Index.h"


// Code enters this function
string indexToString(Index index_to_convert, string end_line = "")
{
    char value_separator=' ';
    string string_type;
    // Order the different parameters of the event, separate them with the appropriate separator, and write them with a line break at the end
    Index::IndexType to_check = index_to_convert.index_type;
    switch(to_check){
        case Index::START :
            string_type="start";
            break;
        case Index::X_POSITION :
            string_type="x";
            break;
        case Index::Y_POSITION :
            string_type="y";
            break;
        case Index::POLARITY :
            string_type="pol";
            break;
    }
    //if(index_to_convert.index_type==Index::X_POSITION)
    //    string_type="x";
    string return_string=string_type+value_separator+to_string(index_to_convert.getValue())+value_separator+to_string(index_to_convert.getInitialTimestamp())+value_separator+to_string(index_to_convert.getNumberOfElements())+end_line;
    return return_string;
}


#endif