#pragma once
#ifndef DIAGNOSTICS_H
#define DIAGNOSTICS_H
#include "../EventScripts/EventManager.h"
#include "../IndexScripts/IndexManager.h"

using namespace std;


// Diagnostics help us understand and visualize information of the data. Please note that if data is very limited diagnostics may produce a wrong output
// For example, it may incorrectly assume that the first x is indeed 3 while it should be either 0 or 1

// None of these functions should run in regular operations, but will remain in code if needed

void printEventQueue(queue<Event>* events_to_print, int max_counter=50)
{
    int current_counter=0;
    cout<<"Printing Event Queue\n";
    while (!(*events_to_print).empty()&&current_counter<max_counter) {
        cout<<eventToString((*events_to_print).front(),' ');
        cout<<" | ";
        (*events_to_print).pop();
        current_counter++;
    }
}

void printIndexQueue(queue<Index>index_to_print, string line_separator=", ", int counter =1000000)
{
    while (!index_to_print.empty()&&counter>0) {
        cout<<indexToString(index_to_print.front(),line_separator);
        index_to_print.pop();
        counter--;
    }
    
}

void printEventVector(vector<Event>events_to_print)
{
    while (!events_to_print.empty()) {
        cout<<eventToString(events_to_print.back(),' ');
        events_to_print.pop_back();
    }
}


void printIdEventQueue(queue<IdEvent>*events_to_print)
{
    cout<<"Printing Event Queue\n";
    while (!(*events_to_print).empty()) {
        cout<<idEventToString((*events_to_print).front(),' ');
        cout<<" | ";
        (*events_to_print).pop();
    }
}




void limitedPrintEventQueue(queue<Event>events_to_print, int counter)
{
    while (!events_to_print.empty()&&counter>0) {
        cout<<eventToString(events_to_print.front(),' ');
        events_to_print.pop();
        counter--;
    }
}

void limited2DPrintEventQueue(queue<queue<Event>>events_to_print, int counter)
{
    //int max_queues=counter;
    int iterative_counter=0;

    while (!events_to_print.empty()&&counter>iterative_counter) {
        
        limitedPrintEventQueue(events_to_print.front(),counter);
        events_to_print.pop();
        iterative_counter++;
    }
    
}

void limited3DPrintEventQueue(queue<queue<queue<Event>>>events_to_print, int counter)
{
    //int max_queues=counter;
    int iterative_counter=0;

    while (!events_to_print.empty()&&counter>iterative_counter) {
        limited2DPrintEventQueue(events_to_print.front(),counter);
        events_to_print.pop();
        iterative_counter++;
    }
    
}

void printEventVectorQueue(vector<queue<Event>>events_to_print, int counter)
{
    while (!events_to_print.empty()) {
        limitedPrintEventQueue(events_to_print.back(),counter);
        events_to_print.pop_back();
    }
}

#endif