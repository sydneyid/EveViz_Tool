#pragma once
#ifndef INPUTOUTPUTMANAGER_H
#define INPUTOUTPUTMANAGER_H
#include <fstream> 

#include <queue>
#include <string>
#include <chrono>

#include "../EventScripts/EventManager.h"
#include "../IndexScripts/IndexManager.h"
#include "../CastingScripts/CastingManager.h"

// TO DO delete all references to cout, and iostream
#include <iostream>




// Code enters this function
void readFileAsStringQueue(string filename, queue<string>* raw_event_queue_pointer, CompressedFileHeader* compressed_file_header_pointer,string header_string)
{
    // Read from the text file
    ifstream input_file;
    input_file.open(filename);

    string current_line;

    int file_line_counter=0;
    const auto tp_start = std::chrono::system_clock::now();

    int counter=0;
    while (getline (input_file, current_line)/*&&counter<5000*/)
    {
        (*raw_event_queue_pointer).push(current_line);
        file_line_counter++;
        counter++;
        
    }
    input_file.close();

    // The first entry in the file is may be the header, which is usually represented as %geometry:1280,720
    if ((*raw_event_queue_pointer).front().rfind(header_string, 0) == 0) { // pos=0 limits the search to the prefix
            (*compressed_file_header_pointer).setHeader((*raw_event_queue_pointer).front()+std::string("\n"));
            (*raw_event_queue_pointer).pop();

    }
    // It is possible to not have a header
    else
    {
        (*compressed_file_header_pointer).setHeader(header_string+std::string("\n"));
        (*compressed_file_header_pointer).setSkipHeader(1);
    }

    
    // Set the number of events
    (*compressed_file_header_pointer).setNumberOfEvents((*raw_event_queue_pointer).size());

    // How much time did it take to read the file
    const auto tp_end       = std::chrono::system_clock::now();
    const double duration_s = std::chrono::duration_cast<std::chrono::microseconds>(tp_end - tp_start).count() / 1e6;

    (*compressed_file_header_pointer).log_entries.push("Decoded '"+filename+"' in "+to_string(duration_s)+" s\n");
}

// Only obtain the compressed file header
string readCompressedFileHeader(string filename)
{
    // It implicitly will only get the header as getline will stop once it finds the char \n which denotes the end of our header
    string return_header_string="";
    // Create and open a text file
    fstream input_file;
    input_file.open(filename, ios::in | ios::binary);

    if (!input_file) {
        cout << "ERROR!! Unable to open file";
        //return 1;
    }

    getline(input_file, return_header_string);

    // Close the file
    input_file.close();
    return return_header_string;
}

// Only obtain the compressed file chars that contain data
void readCompressedFileChars(string filename, int offset, int total_file_size, queue<char>* char_queue)
{
    // Create and open a text file
    fstream input_file;
    input_file.open(filename, ios::in | ios::binary);

    if (!input_file) {
        cout << "ERROR!! Unable to open file";
        //return 1;
    }

    char ch;
    int offset_counter=0;

    // Read the file character by character    , ios::out | ios::binary
    // SKip the header
    while (offset_counter<offset) {
        input_file.read((&ch), sizeof(char));
        //(*char_queue).push(ch);
        offset_counter++;
    }

    cout<<"First char:\n";
    int current_char_counter = 0;
    while(current_char_counter<total_file_size){
        input_file.read((&ch), sizeof(char));

        //if (current_char_counter<1000)
        //    cout<<ch-'0'<<" ";
        (*char_queue).push(ch);
        if(current_char_counter < 30)
            cout<<ch-'0'<<" ";
        current_char_counter++;
    }
    // Close the file
    input_file.close();
}



// Writing files from event queues//
void writeFileFromEventQueue(string filename, queue<Event>* event_queue, CompressedFileHeader* compressed_file_header_pointer)
{
    
    // Create and open a text file
    ofstream MyFile(filename);

    // Write The original header
    if ((*compressed_file_header_pointer).getSkipHeader()==0)
        MyFile << (*compressed_file_header_pointer).getHeader()<<'\n';

    // Write to the file
    while(!(*event_queue).empty())
    {
        MyFile << eventToFileFormat((*event_queue).front(),',');
        (*event_queue).pop();
    }
    // Close the file
    MyFile.close();
}

// Code enters this function
void writeFileFromCharList(string filename, CompressedFileHeader* compressed_file_header_pointer,queue<char>* char_queue_pointer)
{
    fstream test_file(filename, ios::out | ios::binary);
    //test_file.write(reinterpret_cast<const char *>(&size), sizeof(size));
    //test_file.write(&header[0],size);
    
    string header = (*compressed_file_header_pointer).toString();
    int header_char_counter = 0;
    int header_char_size = header.length();

    int first_thirty_chars = 0;

    while (header_char_counter<header_char_size)
    {
        test_file.write(&header[header_char_counter],sizeof(char));
        header_char_counter++;
    }
    string log_first_thirty_chars = "First Thirty Chars for the Index/Events: ";

    while(!(*char_queue_pointer).empty())
    {
        if(first_thirty_chars<30)
        {
            log_first_thirty_chars+=to_string((*char_queue_pointer).front()-'0')+" ";
            first_thirty_chars++;
        }

        test_file.write((&(*char_queue_pointer).front()), sizeof(char));

        int int_cast_test = (*char_queue_pointer).front();

        (*char_queue_pointer).pop();
        

    }
    (*compressed_file_header_pointer).log_entries.push(log_first_thirty_chars+"\n");
    cout<<"\n";

    test_file.close();
}

void writeLogFiles(string filename, CompressedFileHeader* compressed_file_header_pointer)
{
    // Create and open a text file
    ofstream MyFile(filename);

    // Write to the file
    while(!(*compressed_file_header_pointer).log_entries.empty())
    {
        MyFile << (*compressed_file_header_pointer).log_entries.front();
        (*compressed_file_header_pointer).log_entries.pop();
    }
    MyFile << (*compressed_file_header_pointer).toString();

    // Close the file
    MyFile.close();
}

void printLogFiles(CompressedFileHeader* compressed_file_header_pointer)
{
    // Quickly print the Log files for review
    while(!(*compressed_file_header_pointer).log_entries.empty())
    {
        cout << (*compressed_file_header_pointer).log_entries.front();
        (*compressed_file_header_pointer).log_entries.pop();
    }
}
#endif