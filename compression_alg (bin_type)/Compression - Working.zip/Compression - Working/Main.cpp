// Libraries to include
#include <iostream>
#include <fstream> 
#include <queue>
#include <string>

// Files to include
#include "EventScripts/EventManager.h"
#include "InputOutputScripts/InputOutputManager.h"
#include "SortingScripts/SortingManager.h"
#include "InputOutputScripts/Diagnostics.h"
#include "IndexScripts/IndexManager.h"
#include "CompressionScripts/CompressionManager.h"
#include "InputOutputScripts/RawDecoder.h"
#include "InputOutputScripts/RawDecoderEv2.h"
#include "ArithmeticScripts/Arithmetic.h"
#include "CastingScripts/CastingManager.h"
#include "CompressionScripts/CompressedFileHeader.h"



using namespace std;

// Code enters this function
// Compression algorith. Filename is the input, output_filename and write files will write the output and the log files
void compressionAlgorithm(string filename, string output_filename, IndexCompressionAlgorithm compression_algorithm =IndexCompressionAlgorithm::NO_INDEX_COMPRESSION, bool write_log_files = true, string log_filename = "Compression_Logs.txt")
{
        // General Compression variables, save the raw event configuration, the number of events, the raw events, header information, and finally the event queue
                // Maximum number of bucket size for histogram analysis
                static int MAX_ABRIDGED_BUCKET_SIZE = 32;
                // Histogram files help for visualization of index and timestamp compression
                // Clock to check time of compression
                clock_t start, end;
                start = clock();

                // Raw string events, will later be changed 
                queue<string> raw_events_queue;
                queue<string>* raw_events_queue_pointer = &raw_events_queue;

                // Compressed File header that will be attached to the top of the compressed file. One of the most important elements of the code. Will also keep track of the logs that will be written in a file
                CompressedFileHeader compressed_file_header;
                CompressedFileHeader* compressed_file_header_pointer = &compressed_file_header;
                
                // Create events queue
                queue<Event> events_queue;
                queue<Event>* events_queue_pointer= &events_queue;

                // Keeping track of the time of code execution
                const auto now = std::chrono::system_clock::now();
                const std::time_t t_c = std::chrono::system_clock::to_time_t(now);
                (*compressed_file_header_pointer).log_entries.push(std::ctime(&t_c));


        // Read the file 
                // Read a RAW file
                if(filename.substr(filename.find_last_of(".") + 1) == "raw") {
                        (*compressed_file_header_pointer).log_entries.push("Reading a Raw file (Ev3)\n");
                        int raw_code = rawToStringQueue(filename,raw_events_queue_pointer,compressed_file_header_pointer);
                        // Sometimes raw files can be Ev2 included a function to read them here
                        if (raw_code ==2)
                        {
                                (*compressed_file_header_pointer).log_entries.push("Reading a Raw file (Ev2)\n");
                                rawEV2ToStringQueue(filename, raw_events_queue_pointer,compressed_file_header_pointer);
                        }
                }
                // If desired, add here the code to read a HDF5 
                        // Additionally please also record the Header (in the event files there is usually a %geometry:1280,720 to indicate sensor width height) as well as the numbers of events with the following commands
                        //(*compressed_file_header_pointer).setHeader((*raw_event_queue_pointer).front());
                        //(*compressed_file_header_pointer).setNumberOfEvents((*raw_event_queue_pointer).size());
                // Read everything else file (.csv or .txt)
                else
                {
                        // Header String is included if the compressed file doen't have one
                        string header_string="%geometry:1280,720";
                        (*compressed_file_header_pointer).log_entries.push("Reading a txt or csv file\n");
                        readFileAsStringQueue(filename,raw_events_queue_pointer,compressed_file_header_pointer,header_string);
                }

        
        // Quick check to make sure that there are events
                if((*raw_events_queue_pointer).empty())
                {
                        cout<<"Error, raw_events_queue appears to be empty after reading file\n";
                        (*compressed_file_header_pointer).log_entries.push("Error, raw_events_queue appears to be empty after reading file\n");
                        return;
                }
                
                cout<<"Successfully read "<<(*raw_events_queue_pointer).size()<<" raw event lines\n";
                cout<<"First raw event line: "<<(*raw_events_queue_pointer).front()<<"\n";
                cout<<"Expected separator: '"<<(*compressed_file_header_pointer).getEventValueSeparator()<<"'\n";

        // Add events from the string queue
                stringToEventQueue(raw_events_queue_pointer,events_queue_pointer, (*compressed_file_header_pointer).getXMin(), (*compressed_file_header_pointer).getYMin(), (*compressed_file_header_pointer).getEventValueSeparator());

        // Check if events queue is populated
                if((*events_queue_pointer).empty())
                {
                        cout<<"Error, events queue is empty after conversion from strings\n";
                        (*compressed_file_header_pointer).log_entries.push("Error, events queue is empty after conversion\n");
                        return;
                }
                
                cout<<"Successfully converted "<<(*events_queue_pointer).size()<<" events\n";

        // Set The initial Timestamp
                (*compressed_file_header_pointer).setInitialTimestamp((*events_queue_pointer).front().getTimestamp());

        // Compressed events queue by timestamp and index
                // Create the Id event queue, which will facilitate compression as it incudes an id and timestamp compression values
                queue<IdEvent> id_events_queue;
                queue<IdEvent>* id_events_queue_pointer = &id_events_queue;

                // Index queue will help keep track of the number of events, even if the file may not be index compressed
                queue<Index> index_queue;
                queue<Index>* index_queue_pointer = &index_queue;

                // Last Indextype Sort refers to the last category that was used to sort the events, initial value is start as there has been no sorting so far of X Pol or Y. Will help identify how to sort and re-sort for file reconstruction
                Index::IndexType last_indextype_sort = getLastIndexTypeSort(compression_algorithm);

                // Is index encoded can have multiple values each indicating a specific algorithm, 0 means no index compression 7 (111 bit) means X, Y, Pol index compression. 5 (101 bit) fmeans X, Pol compression. Bit = index compressed
                (*compressed_file_header_pointer).setIsIndexEncoded(compression_algorithm);

                // Compress the timestamp, depending on the index
                (*compressed_file_header_pointer).log_entries.push("Timestamp Compression\n");
                hybridIndexTimestampCompression(compressed_file_header_pointer, events_queue_pointer, index_queue_pointer, id_events_queue_pointer, last_indextype_sort, compression_algorithm);


        // Create Histograms for further int size compression
                (*compressed_file_header_pointer).log_entries.push("Histogram Analysis\n");
                int timestamp_buckets[MAX_ABRIDGED_BUCKET_SIZE]={};
                int* timestamp_buckets_pointer = timestamp_buckets;
                for(int i = 0;i<MAX_ABRIDGED_BUCKET_SIZE; i++)
                timestamp_buckets_pointer[i]=0;

                generateHistogramAnalysisIdEvents(/*Inputs*/id_events_queue_pointer,MAX_ABRIDGED_BUCKET_SIZE,/*Outputs*/compressed_file_header_pointer,timestamp_buckets_pointer);

                (*compressed_file_header_pointer).log_entries.push("Index Histogram Analysis\n");
                generateHistogramAnalysisIndex(/*Inputs*/index_queue_pointer, last_indextype_sort, compressed_file_header_pointer);
                cout << "DEBUG: After generateHistogramAnalysisIndex, about to call dictionaryCompressionHistogramAnalysis\n";

                (*compressed_file_header_pointer).log_entries.push("Dictionary Analysis\n");
                dictionaryCompressionHistogramAnalysis(/*Inputs*/timestamp_buckets,compressed_file_header_pointer);
                cout << "DEBUG: After dictionaryCompressionHistogramAnalysis\n";

                (*compressed_file_header_pointer).log_entries.push("Huffman Analysis\n");
                huffmanCompressionHistogramAnalysis(/*Inputs*/timestamp_buckets,compressed_file_header_pointer);

                //Add the appropriate instruction to the events, no instruction, dictionary encoding, huffman short, or huffman long
                addEncodingInstructionToIdEvent(id_events_queue_pointer,compressed_file_header_pointer);
                cout << "DEBUG: After addEncodingInstructionToIdEvent\n";


        // Transform event queue into bits, then rebuild into chars
                queue<char> char_list;
                queue<char>* char_list_pointer = &char_list;
                cout << "DEBUG: About to call bitSpliceIndexListToCharList\n";

                bitSpliceIndexListToCharList(index_queue_pointer, last_indextype_sort, char_list_pointer, compressed_file_header_pointer);
                cout << "DEBUG: After bitSpliceIndexListToCharList\n";

                bitSpliceIdEventListToCharListNoId(id_events_queue_pointer,char_list_pointer,compressed_file_header_pointer);

                (*compressed_file_header_pointer).log_entries.push("Total number of event chars to be written "+to_string((*compressed_file_header_pointer).getNumberOfEventChars())+"\n");
                (*compressed_file_header_pointer).log_entries.push("Total number of chars (with index) to be written "+to_string((*compressed_file_header_pointer).getNumberOfEventChars()+(*compressed_file_header_pointer).getNumberOfIndexEntriesChars())+"\n");

        // Write Files
                cout << "DEBUG: About to call writeFileFromCharList with output: " << output_filename << "\n";
                writeFileFromCharList(output_filename,compressed_file_header_pointer,char_list_pointer);
                cout << "DEBUG: After writeFileFromCharList\n";
                end = clock();
                double time_taken = double(end - start) / double(CLOCKS_PER_SEC);
                
                (*compressed_file_header_pointer).log_entries.push("Total execution time including file writing: "+to_string(time_taken)+" seconds\n");
                if (write_log_files)
                {
                        writeLogFiles(log_filename,compressed_file_header_pointer);
                }
                else
                {
                        printLogFiles(compressed_file_header_pointer);
                }
}

// Code enters this function
void decompressFile(string filename, string output_filename, string file_to_compare = "")
{
    // Initialize variables
                CompressedFileHeader reobtained_compressed_file_header;
                CompressedFileHeader* reobtained_compressed_file_header_pointer = &reobtained_compressed_file_header;
                queue<IdEvent> id_events_from_compressed_file;
                queue<IdEvent>* id_events_from_compressed_file_pointer = &id_events_from_compressed_file;


    cout<<"Continue to read compressed file!\n";

    // Extract the Header
                // Obtain Header string
                string compressed_file_header_string = readCompressedFileHeader(filename);
                // Rebild compressed file header from string
                (*reobtained_compressed_file_header_pointer) = stringToCompressedFileHeader(compressed_file_header_string);




                // TO DO add the numebr of index chars
                int total_file_size = (*reobtained_compressed_file_header_pointer).getNumberOfEventChars();
                int number_of_index_chars = (*reobtained_compressed_file_header_pointer).getNumberOfIndexEntriesChars();
                int number_of_event_chars = (*reobtained_compressed_file_header_pointer).getNumberOfEventChars();
                int number_of_huffman_event_chars = (*reobtained_compressed_file_header_pointer).getNumberOfHuffmanEventChars();
                int number_of_dictionary_event_chars = (*reobtained_compressed_file_header_pointer).getNumberOfDictionaryEventChars();

                int number_of_no_additional_encoding_events_chars = total_file_size - (number_of_index_chars+number_of_huffman_event_chars+number_of_dictionary_event_chars);
                
                cout<<(*reobtained_compressed_file_header_pointer).toString()<<"\n\n";

                //int total_file_size = number_of_index_chars+number_of_huffman_event_chars+number_of_dictionary_event_chars;
                cout<<"total file size: "<<total_file_size;

    // Extract the events and index chars
                queue<char> compressed_file_chars;
                queue<char>* compressed_file_chars_pointer = &compressed_file_chars;
                cout<<"Add +2 to the length of the compressed file header to read only the required chars\n";
                readCompressedFileChars(filename, compressed_file_header_string.length()+2,total_file_size,compressed_file_chars_pointer);
                cout<<"First Char of REOBTAINED EVENTS is: "<<(*compressed_file_chars_pointer).front()-'0'<<"\n";

                queue<Index> index_queue;
                queue<Index>* index_queue_pointer = &index_queue;

    // If existing, rebuild the  index from the chars
                if((*reobtained_compressed_file_header_pointer).getIsIndexEncoded())
                {
                        queue<char> index_chars;
                        queue<char>* index_chars_pointer = &index_chars;

                        spliceCharQueue(compressed_file_chars_pointer,number_of_index_chars,index_chars_pointer);

                        castCharListAsIndex(index_chars_pointer,index_queue_pointer,reobtained_compressed_file_header_pointer);

                }


    // If the events are huffman encoded
                queue<char> event_chars;
                queue<char>* event_chars_pointer = &event_chars;

                // Unmingled because these events weren't moved anywhere
                queue<IdEvent> id_events_unmingled;
                queue<IdEvent>* id_events_unmingled_pointer = &id_events_unmingled;
                
                cout<<"So here first check if there is huffman compression, if not then trigger size is 0, then continue with checking if there is a dictionary event, if so then sort them to the already built IdEvent queue\n";
                if(((*reobtained_compressed_file_header_pointer).getIsHuffmanEncoded()))
                {
                        cout<<"Number of chars for huffman: "<<number_of_huffman_event_chars<<"\n";
                        spliceCharQueue(compressed_file_chars_pointer,number_of_huffman_event_chars,event_chars_pointer);

                        castCharListAsHuffmanIdEvents(event_chars_pointer,id_events_unmingled_pointer,reobtained_compressed_file_header_pointer);
                }

                else
                {
                        cout<<"File is NOT huffman encoded, continue with that consideration: "<<number_of_no_additional_encoding_events_chars<<"\n";
                        spliceCharQueue(compressed_file_chars_pointer,number_of_no_additional_encoding_events_chars,event_chars_pointer);
                        castCharListAsIdEvents(event_chars_pointer,id_events_unmingled_pointer,reobtained_compressed_file_header_pointer);
                }
            
        

     // If the events are dictionary encoded
                queue<IdEvent> sorted_id_events;
                queue<IdEvent>* sorted_id_events_pointer = &sorted_id_events;
                if((*reobtained_compressed_file_header_pointer).getIsDictionaryEncoded())
                {
                        // Splice the queue between dictionary and non-dictionary. The remaining compressed_file_chars_pointer will be dictionary

                        cout<<"Number of chars for dictionary: "<<(*compressed_file_chars_pointer).size()<<"\n";
                        //cout<<"Last Huffman Char: "<<(*event_chars_pointer).back()-'0'<<"\n";


                        queue<IdEvent> dictionary_id_events;
                        queue<IdEvent>* dictionary_id_events_pointer = &dictionary_id_events;

                        // Cast Char List as dictionary id events
                        castCharListAsDictionaryIdEvents(compressed_file_chars_pointer,dictionary_id_events_pointer,reobtained_compressed_file_header_pointer);

                        // Add here the part where we merge dictionary and huffman
                        cout<<"Sorting queue with dictionary events\n";

                        sortEventQueueWithDictionaryIdEventQueue(id_events_unmingled_pointer,dictionary_id_events_pointer, sorted_id_events_pointer,reobtained_compressed_file_header_pointer);
                        
                        }
                // Because there was no dictionary encoding, the unmingled events are already sorted
                else
                {
                        sorted_id_events_pointer = id_events_unmingled_pointer;
                }


        // Delta Decompress the id event queue
                queue<IdEvent> id_events_decompressed;
                queue<IdEvent>* id_events_decompressed_pointer = &id_events_decompressed;

                queue<char> index_compressed_header;
                queue<char> compressed_events;
                queue<char> dictionary_compressed_events;

                deltaDecompressIdEventQueueByAttribute(index_queue_pointer,sorted_id_events_pointer,&IdEvent::getTimestamp,&IdEvent::setTimestamp,id_events_decompressed_pointer,reobtained_compressed_file_header_pointer);


        // Transform the Id Event queue into an event queue
                queue<Event> finalized_events;
                queue<Event>* finalized_events_pointer = &finalized_events;
                
                //decompressIdEventToEvent(id_events_decompressed_pointer,finalized_events_pointer,reobtained_compressed_file_header_pointer);

                decompressIdEventToEvent(id_events_decompressed_pointer,index_queue_pointer,finalized_events_pointer,reobtained_compressed_file_header_pointer);

        // If there is index encoding, sort the id events one more time based on their timestamp
                if((*reobtained_compressed_file_header_pointer).getIsIndexEncoded())
                {
                        reSortEventQueueWithIndex(finalized_events_pointer, index_queue_pointer, reobtained_compressed_file_header_pointer);
                }


        // Write the output file
                cout<<"Writing files";
                writeFileFromEventQueue(output_filename,finalized_events_pointer,reobtained_compressed_file_header_pointer);

}

void help()
{
        cout<<"To properly execute the code please run the following commands:\n";
        cout<<"To Compress write the exe file name, the compression command c, the input filename (can be a .raw or .txt, .hdf5 not implemented), the output name (pleasue use .bin), and the log filename (.txt):\n";
        cout<<"Main.exe c input_filename.raw output_filename.bin log_filename.txt\n";
        cout<<"or\n";
        cout<<"Main.exe c input_filename.raw output_filename.bin\n";
        cout<<"\n";
        cout<<"To Decompress write the exe file name, the decompression command d, the input filename (bin), and the output name (.csv or .txt):\n";
        cout<<"Main.exe d input_filename.bin output_finame.txt\n";
}

// Code enters this function
int main(int argc, char* argv[])
{
        // Command recognzed will indicate if the code will execute or send the help debug message
        bool command_recognized = false;
        char compress_char ='c';
        char decompress_char = 'd';

        if(argc==5)
        {
                char encode_decode = argv[1][0];
                if(encode_decode==compress_char)
                {
                        // Compression algorithm is hardocded as it is the optimal one in the tests
                        IndexCompressionAlgorithm compression_algorithm = IndexCompressionAlgorithm::NO_INDEX_COMPRESSION;

                        //Compress file and create log files
                        compressionAlgorithm(argv[2], argv[3], compression_algorithm, true, argv[4]);
                        command_recognized = true;
                }
        }
        else if(argc==4)
        {
                char encode_decode = argv[1][0];
                if(encode_decode==compress_char)
                {
                        // Compression algorithm is hardocded as it is the optimal one in the tests
                        IndexCompressionAlgorithm compression_algorithm = IndexCompressionAlgorithm::NO_INDEX_COMPRESSION;

                        // Compress file without log file
                        compressionAlgorithm(argv[2], argv[3], compression_algorithm, false);
                        command_recognized = true;
                }
                else  if(encode_decode==decompress_char)
                {
                        // Decompress file
                        decompressFile(argv[2], argv[3]);
                        command_recognized = true;
                }
        }
        if(!command_recognized)
        {
                //compressionAlgorithm("60_DegreePanPerMinute (BERLIN)_Lossy_Events.raw", "NoIndexCompression.bin", IndexCompressionAlgorithm::NO_INDEX_COMPRESSION, true, "NoIndexCompressionLogs.txt");                //decompressFile("PolarityCompressed.bin", "PolarityReobtained.txt");

                help();
        }
        //cout<<"THIS CODE CAN ONLY CAST EVENTS IF THEY ARE LESS THAN 64 BITS, and timestamps are less than 32 bits";
}
