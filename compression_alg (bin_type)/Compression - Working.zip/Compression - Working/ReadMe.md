# EventSat Encoding and Decoding Algorithm
## Backgrounds and Libraries
This is the final version of the encoding and decoding algorithm written by Antonio Junco de Haas as of Septembre 2025. \

Some external libraries for reading the Prophesee Event Camera were utilized, and can be found as RawDecoder.h and RawDecoderEv2.h The link to the repository can be found here: https://github.com/prophesee-ai/openeb/tree/main/standalone_samples

The code was developed using VSCode and compiled with g++.
## Compile the file
Compile Main.cpp to generate the Main.exe.

To complie please utilize this guide https://code.visualstudio.com/docs/languages/cpp \
Install the appropriate C++ extensions

The g++ configuration is as follows\
"g++.exe (Rev2, Built by MSYS2 project) 14.2.0
Copyright (C) 2024 Free Software Foundation, Inc.
This is free software; see the source for copying conditions.  There is NO
warranty; not even for MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE."


To execute the code it possible to choose between the compression "c" command and the decompression "d" command. Indicate the input and the output filenames. \
For compression it is also possible to provide a name for the compression log file that is generated at the same time which provides information that may help debug any issue that may arise during execution

## Run the File
The commands to run the the code are as follws\
### *Compress the inputfile.raw into a compressedfile.bin with outputlogs.txt*
Main.exe c inputfile.raw compressedfile.bin outputlogs.txt

### *Compress the inputfile.raw into a compressedfile.bin without any logs*
Main.exe c inputfile.raw compressedfile.bin

### *Decompress the compressedfile.bin into a finalizedfile.txt*
Main.exe d compressedfile.bin finalizedfile.txt

## Documentation
Code is split into multiple files.
* **Arithmetic.h:** Numerical Methods that help understand data better.
    * **findMaxAtribute:** Receive queue of events or index and return the maximum attribute of the entire list
    * **findMinimumBitsNeeded:** Receive an integer and find how many bits are needed to represent the number
    * **eventQueueToBucket:** Receive a queue and generate an array indicating how many bits are needed for every entry
* **CastingManager.h:** Manipulate data in such a way to store information in the least amount of bits possible, and rebuild the information back to its original format.
    * **castEventAsASingleNumber:** Combine all the numbers in an event to a single number, will help with converting values to chars. Adds a trigger value for huffman comrpession
    * **castEventAsASingleNumberNOTRIGGER:** Same as above without the trigger value, also utilized for dictionary Index and Timestamp
    * **castIdEventAsASingleNumberForDictionary:** Same as above but for dictionary events, remains unused as maximum size of event would only be 64 bits, which may lead to an overflow error
    * **castIndexAsASingleNumber:** Cast an index as a single number
    * **invertLongLong:** Invert the bit order of a long long
    * **castLongLongAsIndex:** Receive a single number and rebuild an index
    * **castLongLongAsIdEventNoId:** Receive a single number and rebuild an event, no id means that no positional element of the id will be retrieved
    * **castLongLongAsIdEvent:** Same as above but retrieves the positional id of the event
    * **castLongLongAsCharList:** Receive a queue of long longs, and build a char list (helps reduce total number of bits). Can also receive a single long long (utilized for dictionary id).
    * **castIdEventListAsDictionaryHeaderCharList:** cast the IdEvents that will be dictionary encoded as a char list
    * **bitSpliceIdEventListToCharListNoId:** Combine all IdEvents into a char list by bitsplicing to save space
    * **bitSpliceIndexListToCharList:** Combine Index into a char list by bitsplicing to save space
    * **spliceCharQueue:** Separate a char queue into two smaller ones
    * **castCharListAsLongLongList:** Rebuild single number elements from a long long list
    * **castCharListAsLongLongListHuffmanVariableSize:** Same as above, but huffman events can be of varying length, therefore this method is able to tell apart the short from the long
    * **castCharListAsIndex:** Rebuild the index queue based from the char list
    * **castCharListAsDictionaryIdEvents:** Rebuild the dictionary IdEvents
    * **castCharListAsIdEvents:** Rebuild the IdEvents, with no additional compression
    * **castCharListAsHuffmanIdEvents:** Rebuild the Huffman IdEvents
    * Additionally there are some debugging functions not utilized in the final build
* **CompressedFileHeader.h:** Perhaps one of the most important data structures of the code. It sets the compression instructions which will help decompress the file once it is sent to the ground station. Throught the whole execution this class instance will be filled out.
    * **CompressedFileHeader Class**
        * *Geometry variables*
            * x_min, x_max, y_min, y_max, polarity - Refer to the camera settings
        * *Minimum required variables*
            * initial timestamp - the first timestamp of the file
            * number_of_event_chars - how many chars are writtten for the events
            * number_of_events - how many total events are in the char
            * event_index_size - How long is the index of the id event per entry
            * event_timestamp_size - How long is the timestamp of each IdEvent
            * header_char_counter - How long is the header in chars which contains all the instructions to decode the file
            * header - The original header of the compressed file, if none is present, assume dimensions as x=1280, y 720
            * value_separator - The char that separates each value of the comrpessed header
            * header_terminator - The last char of the header
            * event_data_separator - The char that separates each element of an event
        * *Additional Compression Algorithms*
        * *Index Compression Algorithm*
            * is_index_encoded - Indicates if there was index compression. 3 bit value indicating if the index was compressed in x_y_pol resulting in a binary value such as 1_1_0 (6) indicating x and y compression.
            * index_number_of_event_size - Indicates the size of the number that shows how many events there are per index
            * index_initial_timestamp_size - Indicates the size of the initial timestamp that will appear on each index
            * number_of_index_entries_chars - How many chars are written into the file
            * number_of_index_entries - Total number of indexes
        * *Dictionary Algorithm*
            * is_dictionary_encoded* - Indicates if there is dictionary encoding within the file
            * dictionary_encoded_id_bit_size - Indicates how long the id of the IdEvent will be
            * dictionary_encoding_timestamp_bit_size - Indicates how long the timestamp for dictionary events will be
            * number_of_dictionary_event_chars - How many chars will be written for the dictionary events
            * number_of_dictionary_events - How many total dictionary events will be written
        * *Huffman Algorithm*
            * is_huffman_encoded - Indicates if there wass huffman comrpession
            * huffman_encoding_timestamp_bit_size - Indicates the bit size of the short huffman event
            * huffman_trigger_size - Indicates the size of the huffman trigger
            * number_of_huffman_event_chars - Number of chars written for huffman events
            * number_of_huffman_events - Number of huffman events
        * Additional functions to get and set all values, as well as a toString to generate the compressed header as it will appear on file

* **CompressionManager:** Contains all the functions that will reduce the overall size of the data
    * **deltaCompressEventQueue:** Apply delta compression with an Index to indicate order of the events
    * **compressEventQueuetoIdEventQueue:** Compress event queue by turning it into an IdEvent queue
    * **compressEventsToIdEvents:** Obtain the correct insturctions to compress the index of an IdEvent, as it may be smaller if there was index compression
    * **hybridIndexTimestampCompression:** Compress the index and the timestamps depending on the compression type. Currently it is always set to have no index comrpession as it is the optimal solution
    * **deltaDecompressIdEventQueueByAttributeNoIndex:** Delta compress a queue without any index guidance
    * **deltaDecompressIdEventQueueByAttributeWithIndex:** Delta compress a queue with index guidance 
    * **deltaDecompressIdEventQueueByAttribute:** Decides if delta decompression is with or without index
    * **dictionaryCompressionHistogramAnalysis:** Run a histogram analysis to see optimal compression for dictionary encoding
    * **addEncodingInstructionToIdEvent:** Add the encoding instructions to all the events, so the program knows which algorithm to execute
    * **huffmanCompressionHistogramAnalysis:** Run a histogram analysis to see optimal compression for huffman encoding
    * **generateHistogramAnalysisIdEvents:** Generate all both huffman and dictionary histogram analysis
    * **generateHistogramAnalysisIndex:** Generate the Index Histogram analysis
    * **decompressIdEventToEventNoIndex:** Decompress the IdEvents back into events with no index guidance
    * **increaseCounterArray:** When each index is spent, this function will let us knwo if there should be a +1 to x, y, and/or pol
    * **decompressIdEventToEventWithIndex:** Decompress the IdEvents into events with index guidance
    * **decompressIdEventToEvent:** Decide if there should or should not be index guidance
* **Event.h:** Contains the two most used classes Event, and IdEvent
    * **Event class:** Unmodified version of the event, where all values are separated
        * uncompressed_timestamp - keeps track of the original timestamp
        * x - x index of the event
        * y - y index of the event
        * polarity - polarity index of the event
        * timestamp - time recorded of the event,  can be modified and compressed
        * Additional functions to get and set values
    * **IdEvent class:** Compressed version of the event, where x, y, and pol are compressed into a single number. 
        * uncompressed_timestamp - keeps track of the original timestamp
        * event_id - numbered position that the IdEven has
        * index_id - x, y, and polarity combined into a single number. If there is index compression then the maximum index id will be reduced,
        * timestamp - time recorded of the event, can be modified and compressed
        * CompressionInstruction - which compression algorithm will be run for this particular IdEvent
        * Additional functions to get and set values
* **EventManager.h:** Additional functions to manage and read events
    * **eventToString:** Receive an event and output a string
    * **idEventToString:** Receive an IdEvent and output a string
    * **eventToFileFormat:** Receive an event and output a string with a specified file format
    * **eventToFileComparisonFormat:** Generate a string for file comparison, useful for debugging
    * **idEventToFileFormat:** IdEvent to file format is only useful for debugging purposes
    * **stringVectorToEvent** Receives vector of string tokens, it then builds and returns the event, useful for debugging
    * **stringToEvent:** Receives a string and generates an Event Object
    * **stringToEventQueue:** Same as above but generates a queue
    * **eventToIdEvent:** Receive an event and transform it to an IdEvent, keeping into account if there is index compression to multiply with the correct values
    * **idEventToEvent:** Revert IdEvent back to an Event
    * Additional get and set methods
* **Index.h:** Indexes are a way to reduce an IdEvent index value by merely indicating how many events have that value (events must be sorted, and original timestamp must also be recorded)
    * initial_timestamp - To make the compression process easier the timestamp of the first event in a particular index is recorded
    * value - indicates the value fo the index, for x [0 - 1279], y[0 - 719], pol[0 - 1]
    * number_of_elements - How many Events share this particular index
    * IndexType - Is this particular index Start (covers all events), X_Position, Y_Position, or Polarity. Whill help identify what was the last index sorted
    * Additional Get and set Functions
* **IndexManager.h:** 
    * indexToString - transform the index into a string

* **Diagnostics.h:**
    * Contains functions not utilized in the final build that can help debugging
* **InputOutputManager.h:** Handles reading and writing files, note that this does not include .raw files
    * **readFileAsStringQueue:** Read a .txt or .csv file as strings to be processed
    * **readCompressedFileHeader:** Read a .bin compressed file, but only extract the header
    * **readCompressedFileChars:** Read a .bin compressed file, exclude the header and only read the data
    * **writeFileFromEventQueue:** Write the final.txt or .csv file after decompression
    * **writeFileFromCharList:** Write the .bin compressed file
    * **writeLogFiles:** Write the log files for debug purposes
    * **printLogFiles:** Can print the log entries to terminal
* **RawDecoder.h:** Developed by Prophesee, modified by EventSat, additional infomation can be found in Backgrounds and Libraries.
    * Reads Ev3 .raw files
    * Code was slightly tweaked to record values to a string queue

* **RawDecoderEv2.h:** Developed by Prophesee, modified by EventSat, additional infomation can be found in Backgrounds and Libraries.
    * Reads Ev2 .raw files
    * Code was slightly tweaked to record values to a string queue
* **Sortingmanager.h:** Sorts events to different orders depending on the necesities
    * **IndexCompressionAlgorithm:** Indicates which type of index compression is utilized, code will only execute NO_INDEX_COMPRESSION as it was found to be the most optimal
    * **GetLastIndexTypeSort:** When comrpessing index, it is important to know what is the last sorting type to keep track of which order the next encoding instruction will be
    * **transferAllVectorStackToQueue:** Receives a verctor of event queues and transforms them into a single queue
    * **partitionQueue:** Receives a queue and splits it into two with by a certain amount
    * **indexSortWithoutIndex:** Sort events for the first time without an index, uses non-comparative sorting
    * **indexSortUsingIndex:** Sort events for the first time without an index, uses non-comparative sorting
    * **indexSort:** Chooses between indexSortWithoutIndex and indexSortUsingIndex
    * **sortIndexGeneralAlgortihm:** Receives an instruction of IndexCompressionAlgorithm, and executes howver many sorts are necessary in x y and polarity
    * **reSortEventQueueWithIndex:** Rebuild an event queue back to its original order **IMPORTANT, introduces a systematical bias if two events have the same bias, as it can't tell apart which one is first, as such index comrpession was abandoned, since file integrity is broken at this point**
    * **transferArrayQueueToIdEventQueue:** Transfers an array to a queue
    * **sortEventQueueWithDictionaryIdEventQueue:** Re introduces the dictionary events to the correct order
* **Main.cpp:** Is the file that will generate the .exe file, instructions on how to run can be seen in the above documentation
    * **compressionAlgorithm:** Receives a file and generates a .bin comrpessed file
        * Reads the file as strings
        * Transforms strings to events
        * Compress timestamp and index by creating IdEvents
        * Generates Histograms for compression analysis
        * Compresses with dictionary and huffman algorithms
        * Bit splices events into chars
        * Writes files
    * **decompressFile:** Receives a file and generates a .bin comrpessed file
        * Extracts the header from the compressed file
        * Extracts the data from the file
        * Rebuilds indexes (if there was index encoding)
        * Rebuilds huffman encoded events
        * Rebuilds dictionary encoded events
        * Delta decomrpession
        * Transform IdEvents back into events
        * If there is index compression sort events (breaks file integrity)
        * Write files
    * **help:**
        * Provides information on how to properly run the code
    * **main:**
        * Receives filenames, and instuctions, will then run compression, decompression, or help funcitons

