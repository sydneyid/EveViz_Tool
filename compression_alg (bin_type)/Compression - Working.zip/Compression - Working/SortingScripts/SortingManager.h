#pragma once
#ifndef SORTINGMANAGER_H
#define SORTINGMANAGER_H

#include "../EventScripts/EventManager.h"
#include "../InputOutputScripts/Diagnostics.h"
#include "../IndexScripts/Index.h"
#include <stack>

// Sorts the events to appropriate order, in general this will not be executed since there is no index compression, but the general algorithm is called briefly


// The compression algorithm that will be utilized, in general only use the NO_INDEX_COMPRESSION, as tests indicated that this one was the optimal
enum IndexCompressionAlgorithm
{
    NO_INDEX_COMPRESSION,
    POLARITY_COMPRESSION,
    Y_COMPRESSION,
    Y_POLARITY_COMPRESSION,
    X_COMPRESSION,
    X_POLARITY_COMPRESSION,
    X_Y_COMPRESSION,
    X_Y_POlARITY_COMPRESSION
};

// The last sorting algorithm was based on which index value x, y, or pol? The order is always the same
Index::IndexType getLastIndexTypeSort(IndexCompressionAlgorithm compression_algorithm)
{
    switch(compression_algorithm)
    {
        case (IndexCompressionAlgorithm::NO_INDEX_COMPRESSION):
            return Index::IndexType::START;
        break;
        case (IndexCompressionAlgorithm::POLARITY_COMPRESSION):
            return Index::IndexType::POLARITY;
        break;
        case (IndexCompressionAlgorithm::Y_COMPRESSION):
            return Index::IndexType::Y_POSITION;
        break;
        case (IndexCompressionAlgorithm::X_COMPRESSION):
            return Index::IndexType::X_POSITION;
        break;
        case (IndexCompressionAlgorithm::Y_POLARITY_COMPRESSION):
            return Index::IndexType::POLARITY;
        break;
        case (IndexCompressionAlgorithm::X_POLARITY_COMPRESSION):
            return Index::IndexType::POLARITY;
        break;
        case (IndexCompressionAlgorithm::X_Y_COMPRESSION):
            return Index::IndexType::Y_POSITION;
        break;
        case (IndexCompressionAlgorithm::X_Y_POlARITY_COMPRESSION):
            return Index::IndexType::POLARITY;
        break;
        default:
            return Index::IndexType::START;
        break;

    }

}

/*Event Sorting Algorithms*/
// Receive a vector with queues of events, and output a single sorted queue of events
void transferAllVectorStackToQueue(vector<queue<Event>>* vector_queue, queue<Event>* sorted_events, int (*get_function_pointer)(Event),  int minimum_value, int maximum_value, int* index_array){
    // This is a generic sorting algorithm, so you can send which value to sort with by utilizing function pointers, choose between sorting by X, Y, or Polarity
    // Vector allows us to sort withoug comparison, as values are sorted directly to their index
    int quick_counter=0;
    for (int i = maximum_value-minimum_value; i>=0; i--)
    {
        int counter=0;
        while(!((*vector_queue)[i]).empty())
        {
            Event current_event=(*vector_queue)[i].front();
            int sorting_value = (*get_function_pointer)(current_event)-minimum_value;

            *(index_array+sorting_value)=(*(index_array+sorting_value))+1;
            (*sorted_events).push(current_event);
            (*vector_queue)[i].pop();
            counter++;
            quick_counter++;
        }

    }

}

// Cut apart a queue by a specified amount
void partitionQueue(int amount,queue<Event>* general_events, queue<Event>* partitioned_events)
{
    Event current_event = (*general_events).front();
    while(amount>0)
    {
        current_event=(*general_events).front();
        (*partitioned_events).push((*general_events).front());
        (*general_events).pop();
        amount--;
        
    }
}

// Sort an event queue by index, in this case there is yet to be an index created, so it generates one
void indexSortWithoutIndex(queue<Index>* index_queue_pointer,queue<Event>* unsorted_events, queue<Event>* sorted_events, Index::IndexType output_sorting_type, int min, int max, CompressedFileHeader* compressed_file_header_pointer)
{
    cout<<"DEBUG: Entering indexSortWithoutIndex. unsorted_events size: "<<(*unsorted_events).size()<<"\n";
    
    int total_number_of_elements=0;
    (*index_queue_pointer).push(Index(Index::START,0,(*unsorted_events).front().getTimestamp(),0));



    int (*get_function_pointer)(Event test_event);
    switch (output_sorting_type)
    {
        case (Index::X_POSITION):
            get_function_pointer=getX;
        break;
        case (Index::Y_POSITION):
            get_function_pointer=getY;
        break;
        case (Index::POLARITY):
            get_function_pointer=getPolarity;
        break;
        default:
            cout<<"ERROR! something happended with the function poiniter";
        break;
    }

    // Temporary vector queue event, each vector index represents a pixel in camera, and queue is the number of events that occur in it
    vector<queue<Event>> sorted_vector(max+1-(min));

    // If the minimum value is different than 0, you must substract by the mnimum value so the vector doesn't waste a space
    // We do the max so we can push back in the vector afterwards. As Vector works as a stack rather than a queue
    while (!(*unsorted_events).empty()) 
    {
        // Find the event to sort
        Event current_event=(*unsorted_events).front();
        // Order them inversly
        sorted_vector[max-((*get_function_pointer)(current_event))].push(current_event);

        (*unsorted_events).pop();
        //int_counter_1++;
    }

    // We do the max so we can push backsor in the vector afterwards. As Vector works as a stack rather than a queue
    int index_counter=min;
    int event_counter=0;
    //int initial_timestamp=0;
    while(!sorted_vector.empty())
    {
        event_counter=0;
        //if (!sorted_vector.back().empty())
        //    initial_timestamp = sorted_vector.back().front().getTimestamp();

        while(!sorted_vector.back().empty()){
            Event current_event=sorted_vector.back().front();
            (*sorted_events).push(current_event);
            sorted_vector.back().pop();
            event_counter++;
            //int_counter_2++;
        }
        (*index_queue_pointer).push(Index(output_sorting_type,index_counter,/*initial_timestamp,*/event_counter));
        total_number_of_elements+=event_counter;
        index_counter++;
        sorted_vector.pop_back();
    }
    
    // Only set number of elements if index queue has elements beyond the START index
    if(!(*index_queue_pointer).empty())
    {
        (*index_queue_pointer).front().setNumberOfElements(total_number_of_elements);
    }
    //(*compressed_file_header_pointer).setNumberofIndexEntries(index_counter);
}

// Index queue pointer is the indexes that will be part of the document header, unsorted events is the raw data generated by event camera, sorted events is where to store the ordered events, sorting type is for X Y or polarity sort, min and max are the min and max values obtained from config doc
void indexSortUsingIndex(queue<Index>* index_queue_pointer, queue<Event>* unsorted_events, queue<Event>* sorted_events, Index::IndexType input_sorting_type, Index::IndexType output_sorting_type, int min, int max, CompressedFileHeader* compressed_file_header_pointer)
{
    // Check if index queue is empty
    if((*index_queue_pointer).empty())
    {
        cout<<"ERROR: Index queue is empty in indexSortUsingIndex. Cannot proceed.\n";
        return;
    }
    
    int number_of_indexes = 0;
    int (*get_function_pointer)(Event test_event);
    switch (output_sorting_type)
    {
        case (Index::X_POSITION):
            get_function_pointer=getX;
        break;
        case (Index::Y_POSITION):
            get_function_pointer=getY;
        break;
        case (Index::POLARITY):
            get_function_pointer=getPolarity;
        break;
        default:
            cout<<"ERROR! something happended with the function poiniter";
        break;
    }
    // Receive thre front index, to check if it is start, if not, there must have been an error
    Index front_index = (*index_queue_pointer).front();

    if(front_index.index_type!=Index::START){
        cout<<"ERROR the index first element was not start, this means the index queue is not correctly used. Please start the queue with a start type, and push it at the end for iteration purposes";
    }

    // Loop the start event to the back, will help us know when we have fully gone over the indexes
    (*index_queue_pointer).pop();
    (*index_queue_pointer).push(front_index);
    number_of_indexes++;

    // Because we already have an index set up, we will iterate until we find the start again thanks to the Index::START tag
    while ((*index_queue_pointer).front().index_type!=Index::START) 
    {  
        Index current_index=(*index_queue_pointer).front();
        (*index_queue_pointer).push(current_index);
        number_of_indexes++;
        (*index_queue_pointer).pop();

        // If the index is of a different type than the input, we skip it. You enter here when you already sorted by X and Y, but still need to do polarity by Y. You would then skip all the X 
        if(current_index.index_type==input_sorting_type)
        {
            // The size of the vector is the range of the values, can be seen in the event camera configuration file
            // We use pointers for the queues for faster processes
            vector<queue<Event>> sorted_vector(max+1-(min));
            vector<queue<Event>>* sorted_vector_pointer=&sorted_vector;
            queue<Event> partitioned_queue;
            queue<Event>* partitioned_queue_pointer=&partitioned_queue;

            // Partition the event queue until where the current index tells us, will help with sorting quicker
            partitionQueue(current_index.getNumberOfElements(),unsorted_events,partitioned_queue_pointer);

            //int initial_timestamp = 0;
            // Check if the partition is empty
            if(!partitioned_queue.empty())
            {
                //initial_timestamp = partitioned_queue.front().getTimestamp();
                // While there are still values in the partitioned queue sort them
                while(!partitioned_queue.empty())
                {
                    Event current_event = partitioned_queue.front();
                    sorted_vector[max-(*get_function_pointer)(current_event)].push(current_event);
                    partitioned_queue.pop();    
                }
            }
            // Create an array of ints for the indexes, will later be added to the queue
            int index_array [max-min]={0};
            // Loop through array to set 0s, as null values or unused may cause errors
            for (int i = 0; i <= (max-min); i++) 
                index_array[i]=0;
            
                // Use pointer as it is faster than copying the array
            int* index_array_pointer = &index_array[0];

            // EMPTY sorted_vector and add sorted events to the queue
            transferAllVectorStackToQueue(sorted_vector_pointer, sorted_events, get_function_pointer, min, max, index_array_pointer);

            // Add all the values from the array as indexes
            for(int i = 0; i<=(max-min); i++)
            {
                (*index_queue_pointer).push(Index(output_sorting_type,i+min,index_array[i]));

                if(output_sorting_type == input_sorting_type)
                    number_of_indexes++;
                    
            }
        }
    }
    
}

// Sort the events based on index values and with the special instruction
void indexSort(queue<Index>* index_queue_pointer, queue<Event>* unsorted_events, queue<Event>* sorted_events,Index::IndexType input_sorting_type, Index::IndexType output_sorting_type, CompressedFileHeader* compressed_file_header_pointer)
{
    int min = 0;
    int max = 0;
    // Set the values of min and max, it depends on what do you want your output sorting type to be
    switch(output_sorting_type)
    {
        case Index::X_POSITION:
        min = (*compressed_file_header_pointer).getXMin();
        max = (*compressed_file_header_pointer).getXMax();
        break;

        case Index::Y_POSITION:
        min = (*compressed_file_header_pointer).getYMin();
        max = (*compressed_file_header_pointer).getYMax();
        break;

        case Index::POLARITY:
        min = 0;
        max = (*compressed_file_header_pointer).getPolarity();
        break;
    }

    // C++ allows very fast programming by referencing values with pointers rather than copying values
    // This means that currently the index is completely empty except for the START Index. This will help reduce number of operations
    if (input_sorting_type==Index::START)
    {
        indexSortWithoutIndex(index_queue_pointer,unsorted_events,sorted_events,output_sorting_type,min,max,compressed_file_header_pointer);
    }
    // This means that there is already an index, so you can sort Y based on previous X indexes
    else
    {
        indexSortUsingIndex(index_queue_pointer,unsorted_events,sorted_events,input_sorting_type,output_sorting_type,min,max,compressed_file_header_pointer);
    }
}

// Code enters this function
// Selects a certain algorithm for index sort based on the attributes of the index, or in case of no index compression, skip the sorting altogether
void sortIndexGeneralAlgortihm(queue<Event>* input_events_queue_pointer, queue<Event>* sorted_events_queue_pointer, queue<Index>* index_queue_pointer, Index::IndexType last_indextype_sort,  CompressedFileHeader* compressed_file_header_pointer, IndexCompressionAlgorithm index_compression_algorithm=IndexCompressionAlgorithm::NO_INDEX_COMPRESSION)
{
    cout<<"DEBUG: sortIndexGeneralAlgortihm START\n";
    cout<<"DEBUG: Algorithm value: "<<index_compression_algorithm<<"\n";
    cout<<"DEBUG: About to create intermediary_sorter\n";
    
    queue<Event> intermediary_sorter;
    queue<Event>* intermediary_sorter_pointer = &intermediary_sorter;

    cout<<"DEBUG: intermediary_sorter created, entering switch\n";
    
    // SORTING ALGROITHMS, depending on the instruction it will execute a X, Y, Polarity sort. In that order
    switch(index_compression_algorithm)
    {
        case(NO_INDEX_COMPRESSION):
        cout<<"DEBUG: In NO_INDEX_COMPRESSION case\n";
        (*compressed_file_header_pointer).log_entries.push("Working in no index compression\n");
        //No additional sorted needed, just add the initial index for start
        (*index_queue_pointer).push(Index(Index::START,0,(*compressed_file_header_pointer).getInitialTimestamp(),(*compressed_file_header_pointer).getNumberOfEvents()));
        cout<<"DEBUG: Pushed START index\n";
        //(*compressed_file_header_pointer).setEventIndexSize(1);
        last_indextype_sort=Index::START;
        
        break;

        case(POLARITY_COMPRESSION):
        (*compressed_file_header_pointer).log_entries.push("Working in polarity compression\n");
        indexSort(index_queue_pointer,input_events_queue_pointer,sorted_events_queue_pointer,Index::START,Index::POLARITY,compressed_file_header_pointer);
        last_indextype_sort=Index::POLARITY;
        break;

        case(Y_COMPRESSION):
        (*compressed_file_header_pointer).log_entries.push("Working in y compression\n");
        indexSort(index_queue_pointer,input_events_queue_pointer,sorted_events_queue_pointer,Index::START,Index::Y_POSITION,compressed_file_header_pointer);
        last_indextype_sort=Index::Y_POSITION;
        break;

        case(X_COMPRESSION):
        (*compressed_file_header_pointer).log_entries.push("Working in x compression\n");
        indexSort(index_queue_pointer,input_events_queue_pointer,sorted_events_queue_pointer,Index::START,Index::X_POSITION,compressed_file_header_pointer);
        last_indextype_sort=Index::X_POSITION;
        break;

        case(Y_POLARITY_COMPRESSION):
        (*compressed_file_header_pointer).log_entries.push("Working in y polarity compression\n");
        indexSort(index_queue_pointer,input_events_queue_pointer,intermediary_sorter_pointer,Index::START,Index::Y_POSITION,compressed_file_header_pointer);
        indexSort(index_queue_pointer,intermediary_sorter_pointer,sorted_events_queue_pointer,Index::Y_POSITION,Index::POLARITY,compressed_file_header_pointer);
        last_indextype_sort=Index::POLARITY;
        break;

        case(X_POLARITY_COMPRESSION):
        (*compressed_file_header_pointer).log_entries.push("Working in x polarity compression\n");
        indexSort(index_queue_pointer,input_events_queue_pointer,intermediary_sorter_pointer,Index::START,Index::X_POSITION,compressed_file_header_pointer);
        indexSort(index_queue_pointer,intermediary_sorter_pointer,sorted_events_queue_pointer,Index::X_POSITION,Index::POLARITY,compressed_file_header_pointer);
        last_indextype_sort=Index::POLARITY;
        break;

        case(X_Y_COMPRESSION):
        (*compressed_file_header_pointer).log_entries.push("Working in x y compression\n");
        indexSort(index_queue_pointer,input_events_queue_pointer,intermediary_sorter_pointer,Index::START,Index::X_POSITION,compressed_file_header_pointer);
        indexSort(index_queue_pointer,intermediary_sorter_pointer,sorted_events_queue_pointer,Index::X_POSITION,Index::Y_POSITION,compressed_file_header_pointer);
        last_indextype_sort=Index::Y_POSITION;
        break;

        case(X_Y_POlARITY_COMPRESSION):
        (*compressed_file_header_pointer).log_entries.push("Working in x y polarity compression\n");
        indexSort(index_queue_pointer,input_events_queue_pointer,intermediary_sorter_pointer,Index::START,Index::X_POSITION,compressed_file_header_pointer);
        indexSort(index_queue_pointer,intermediary_sorter_pointer,input_events_queue_pointer,Index::X_POSITION,Index::Y_POSITION,compressed_file_header_pointer);
        indexSort(index_queue_pointer,input_events_queue_pointer,sorted_events_queue_pointer,Index::Y_POSITION,Index::POLARITY,compressed_file_header_pointer);
        last_indextype_sort=Index::POLARITY;
        break;
        

    }
}

// After receiving the events rebuild the correct order using the index
void reSortEventQueueWithIndex(queue<Event>* event_queue_pointer, queue<Index>* index_queue_pointer, CompressedFileHeader* compressed_file_header_pointer)
{
    // If the file is index encoded execute these instructions, else you can skip them
    if((*compressed_file_header_pointer).getIsIndexEncoded())
    {
        int index_queue_size = (*index_queue_pointer).size();
        vector<queue<Event>> sorted_vector(index_queue_size);
        vector<queue<Event>>* sorted_vector_pointer=&sorted_vector;
        queue<Event> partitioned_queue;
        queue<Event>* partitioned_queue_pointer=&partitioned_queue;
        int index_position_counter = 0;
        Index current_index = (*index_queue_pointer).front();
        

        int current_number_of_events = 0;
        int number_of_events = (*compressed_file_header_pointer).getNumberOfDictionaryEvents()+(*compressed_file_header_pointer).getNumberOfHuffmanEvents();
        cout<<"Sorting algorithm\n";
        cout<<"Index size: "<<index_queue_size<<"\n";

        while (!(*index_queue_pointer).empty()) 
        {
            current_index = (*index_queue_pointer).front();
            // Partition the event queue until where the current index tells us, will help with sorting quicker
            partitionQueue(current_index.getNumberOfElements(),event_queue_pointer,partitioned_queue_pointer);

            // Check if the partition is empty
            if(!partitioned_queue.empty())
            {
                // While there are still values in the partitioned queue sort them
                while(!partitioned_queue.empty())
                {
                    //TO DO, it appears that the event is null because there are no more elements in unsorted/partitioned
                    Event current_event = partitioned_queue.front();
                    
                    sorted_vector[index_position_counter].push(current_event);
                    partitioned_queue.pop();    
                }
            }
            index_position_counter++;

            (*index_queue_pointer).pop();
        }
        bool first_non_empty_element = true; 
        Event smallest_iterated_event;
        int index_of_smallest_event = 0;
        while(current_number_of_events<number_of_events)
        {
            // Find the smallest event
            for (int i = 0; i<index_queue_size;i++)
            {
                if(!(sorted_vector[i].empty()))
                {
                    if(first_non_empty_element)
                    {
                        index_of_smallest_event = i;
                        smallest_iterated_event = sorted_vector[i].front();
                        first_non_empty_element = false;
                    }
                    if (smallest_iterated_event.getTimestamp()>sorted_vector[i].front().getTimestamp())
                    {
                        index_of_smallest_event = i;
                        smallest_iterated_event = sorted_vector[i].front();
                    }
                }


            }
            first_non_empty_element = true;
            current_number_of_events++;
            (*event_queue_pointer).push(smallest_iterated_event);
            sorted_vector[index_of_smallest_event].pop();
        }
    }
}


/*******************************************************************************************************/
/*IdEvent Sorting Algorithm*/
void transferArrayQueueToIdEventQueue(queue<IdEvent>** queue_array, queue<IdEvent>* sorted_events, int max_range){
    // This is a generic sorting algorithm, so you can send which value to sort with by utilizing function pointers, choose between sorting by X, Y, or Polarity
    for (int i = 0; i<max_range; i++)
    {
        while(!(*((*queue_array)+i)).empty())
        {
            IdEvent current_event=(*(*queue_array+i)).front();
            (*sorted_events).push(current_event);
            (*(*queue_array+i)).pop();
        }

    }
    cout<<"\nFinished Transfer\n";

}

// Sort dictionary and huffman events

void sortEventQueueWithDictionaryIdEventQueue(queue<IdEvent>* id_event_queue, queue<IdEvent>* dictionary_id_event_queue, queue<IdEvent>* finalized_id_event_queue,CompressedFileHeader* compressed_file_header_pointer)
{
    int dictionary_id = (*dictionary_id_event_queue).front().getEventId();
    int current_event_counter = 0;
    IdEvent event_to_be_added;

    cout<<"Last Non-Dictionary id event "<<idEventToString((*id_event_queue).back());

    cout<<"First Dictionary id event "<<idEventToString((*dictionary_id_event_queue).front());

    cout<<"Last Dictionary id event "<<idEventToString((*dictionary_id_event_queue).back());
    
    while ((!(*dictionary_id_event_queue).empty())||(!(*id_event_queue).empty()))
    {
        //DEBUG
        // If the current id is the same as the next event, add it here
        if(current_event_counter == dictionary_id)
        {
            (*finalized_id_event_queue).push((*dictionary_id_event_queue).front());
            (*dictionary_id_event_queue).pop();
            // Push the event to the finalized id event queue
            // If there are still remaining, get the next dictionary id
            if(!(*dictionary_id_event_queue).empty())
            {
                dictionary_id = (*dictionary_id_event_queue).front().getEventId();
            }
            else{
                cout<<"Dictionary queue is empty at "<<current_event_counter<<" events\n";
            }
            current_event_counter++;
        }
        else
        {
            if ((*id_event_queue).empty())
                break;
            (*finalized_id_event_queue).push((*id_event_queue).front());
            (*id_event_queue).pop();
            current_event_counter++;
        }
        
    }
    if ((*dictionary_id_event_queue).empty()&&(*id_event_queue).empty())
    {
        cout<<"Both queues are empty, Total events:"<<current_event_counter<<"\n";
    }
}


#endif